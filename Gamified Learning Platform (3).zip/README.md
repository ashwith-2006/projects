
  # Gamified Learning Platform

  This is a code bundle for Gamified Learning Platform. The original project is available at https://www.figma.com/design/ej0uaK2awSU2derCHq5FnF/Gamified-Learning-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  