# NextEd Testing Guide

## Quick Start: Creating Your First Accounts

### ⚠️ Important: Sign Up BEFORE Login

**The error you saw means you tried to login before creating an account!**

Follow these steps in order:

---

## Step 1: Create a Teacher Account

1. **Click "Sign Up"** (NOT Login)
2. **Select "Teacher" tab**
3. **Fill in the form:**
   - **Name:** Ms. Sharma
   - **Email:** teacher@demo.com
   - **Password:** Demo123 (at least 6 characters)
   - **Grade Teaching:** 8
   - **Subject:** Mathematics
   - **School ID:** SCH001

4. **Click "Sign Up" button**
5. ✅ You'll be automatically logged in!

---

## Step 2: Create Student Accounts

### Student 1
1. **Log out** from teacher account
2. **Click "Sign Up"** (NOT Login)
3. **Select "Student" tab**
4. **Fill in the form:**
   - **Name:** Rahul Kumar
   - **Email:** rahul@demo.com
   - **Password:** Demo123
   - **Grade:** 8
   - **School ID:** SCH001 (SAME as teacher!)

5. **Click "Sign Up" button**

### Student 2
1. **Log out**
2. **Sign up another student:**
   - **Name:** Priya Sharma
   - **Email:** priya@demo.com
   - **Password:** Demo123
   - **Grade:** 8
   - **School ID:** SCH001

---

## Step 3: Verify School Isolation

### Create a teacher from a DIFFERENT school:

1. **Sign up as:**
   - **Name:** Mrs. Patel
   - **Email:** teacher2@demo.com
   - **Password:** Demo123
   - **Grade Teaching:** 8
   - **Subject:** Science
   - **School ID:** SCH002 (DIFFERENT school!)

2. **Login as Mrs. Patel**
3. ✅ She should see **0 students** (because no students from SCH002 exist yet)

4. **Login as Ms. Sharma** (teacher@demo.com)
5. ✅ She should see **2 students** (Rahul and Priya from SCH001, Grade 8)

---

## Common Errors and Solutions

### ❌ "Invalid login credentials"
**Problem:** You're trying to login with an account that doesn't exist yet.  
**Solution:** Click "Sign Up" first to create the account!

### ❌ "Missing required fields"
**Problem:** You didn't fill in all required fields.  
**Solution:** Make sure you fill in:
- For Students: Name, Email, Password, Grade, School ID
- For Teachers: Name, Email, Password, Grade Teaching, Subject, School ID

### ❌ "Password must be at least 6 characters"
**Problem:** Your password is too short.  
**Solution:** Use at least 6 characters (e.g., "Demo123")

---

## Testing School-Based Filtering

### Scenario: Two Schools, Same Grade

**School A (SCH001) - Grade 8:**
- Teacher: Ms. Sharma (teacher@demo.com)
- Students: Rahul, Priya

**School B (SCH002) - Grade 8:**
- Teacher: Mrs. Patel (teacher2@demo.com)
- Students: (none yet)

### What to test:

1. **Login as Ms. Sharma**
   - Should see: Rahul and Priya
   - Should NOT see: Students from other schools

2. **Login as Mrs. Patel**
   - Should see: 0 students (no one from SCH002 yet)
   - Should NOT see: Rahul or Priya (they're in SCH001)

3. **Create a student in SCH002:**
   - Name: Amit Shah
   - Email: amit@demo.com
   - Grade: 8
   - School ID: SCH002

4. **Login as Mrs. Patel again**
   - Should NOW see: Amit
   - Should still NOT see: Rahul or Priya

---

## Testing Grade-Based Filtering

### Scenario: Same School, Different Grades

**School A (SCH001):**
- **Grade 8:**
  - Teacher: Ms. Sharma
  - Students: Rahul, Priya
  
- **Grade 7:**
  - Teacher: Mr. Kumar (teacher3@demo.com)
  - Students: (create some)

### Create Grade 7 Teacher:

1. **Sign up:**
   - Name: Mr. Kumar
   - Email: teacher3@demo.com
   - Password: Demo123
   - Grade Teaching: 7 (different grade!)
   - Subject: Science
   - School ID: SCH001 (same school!)

2. **Login as Mr. Kumar**
   - Should see: 0 students (no Grade 7 students yet)
   - Should NOT see: Rahul or Priya (they're in Grade 8)

3. **Create a Grade 7 student:**
   - Name: Arjun Singh
   - Email: arjun@demo.com
   - Grade: 7
   - School ID: SCH001

4. **Login as Mr. Kumar**
   - Should see: Arjun only
   - Should NOT see: Grade 8 students

5. **Login as Ms. Sharma**
   - Should see: Rahul and Priya (Grade 8)
   - Should NOT see: Arjun (Grade 7)

---

## Sample Test Accounts

### Teachers

| Name | Email | Password | School ID | Grade | Subject |
|------|-------|----------|-----------|-------|---------|
| Ms. Sharma | teacher@demo.com | Demo123 | SCH001 | 8 | Math |
| Mrs. Patel | teacher2@demo.com | Demo123 | SCH002 | 8 | Science |
| Mr. Kumar | teacher3@demo.com | Demo123 | SCH001 | 7 | Science |

### Students

| Name | Email | Password | School ID | Grade |
|------|-------|----------|-----------|-------|
| Rahul Kumar | rahul@demo.com | Demo123 | SCH001 | 8 |
| Priya Sharma | priya@demo.com | Demo123 | SCH001 | 8 |
| Amit Shah | amit@demo.com | Demo123 | SCH002 | 8 |
| Arjun Singh | arjun@demo.com | Demo123 | SCH001 | 7 |

---

## Expected Results

### When logged in as Ms. Sharma (SCH001, Grade 8):
- ✅ Sees: Rahul, Priya
- ❌ Does NOT see: Amit (different school), Arjun (different grade)

### When logged in as Mrs. Patel (SCH002, Grade 8):
- ✅ Sees: Amit
- ❌ Does NOT see: Rahul, Priya, Arjun (all from different school)

### When logged in as Mr. Kumar (SCH001, Grade 7):
- ✅ Sees: Arjun
- ❌ Does NOT see: Rahul, Priya (different grade), Amit (different school)

---

## Tips for Testing

1. **Use different browser tabs** for different users
2. **Use the same School ID** to connect teachers and students
3. **Grades must match exactly** (both as strings: "8" not 8)
4. **Email must be unique** for each account
5. **Remember to sign up BEFORE login!**

---

## Next Steps After Testing

Once you've verified the school-based filtering works:

1. Test the student dashboard features (levels, points, streaks)
2. Test the AI tutor functionality
3. Test multi-language switching
4. Add more realistic course content
5. Implement course management for teachers

---

## Need Help?

If something isn't working:

1. **Check browser console** (F12) for error messages
2. **Verify School IDs match exactly** (case-sensitive!)
3. **Make sure you signed up first** before trying to login
4. **Clear localStorage** and start fresh if needed:
   ```javascript
   localStorage.clear()
   ```
   Then refresh the page

---

Happy Testing! 🚀