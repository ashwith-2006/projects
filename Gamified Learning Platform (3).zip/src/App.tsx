import { useState, useEffect } from "react";
import { IntroPage } from "./components/IntroPage";
import { AuthPage } from "./components/AuthPage";
import { OTPVerificationPage } from "./components/OTPVerificationPage";
import { StudentDashboard } from "./components/StudentDashboard";
import { TeacherDashboard } from "./components/TeacherDashboard";
import {
  LanguageProvider,
  useLanguage,
} from "./components/LanguageContext";
import {
  getProfile,
  getAccessToken,
  verifyOTP,
  signUp,
} from "./utils/api";

type AppPage =
  | "intro"
  | "student-auth"
  | "teacher-auth"
  | "otp-verification"
  | "student-dashboard"
  | "teacher-dashboard";

function AppContent() {
  const [currentPage, setCurrentPage] =
    useState<AppPage>("intro");
  const [userType, setUserType] = useState<
    "student" | "teacher"
  >("student");
  const [user, setUser] = useState<{
    type: "student" | "teacher";
    name: string;
    grade?: string;
    subject?: string;
    schoolId?: string;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [otpData, setOtpData] = useState<{
    phone: string;
    otp?: string;
    isLogin: boolean;
    formData: any;
    demoMode?: boolean;
  } | null>(null);

  useEffect(() => {
    checkExistingSession();
  }, []);

  const checkExistingSession = async () => {
    try {
      const token = getAccessToken();
      if (token) {
        const response = await getProfile();
        if (response.success && response.user) {
          setUser({
            type: response.user.userType,
            name: response.user.name,
            grade: response.user.grade,
            subject: response.user.subject,
            schoolId: response.user.schoolId,
          });
          setCurrentPage(
            response.user.userType === "student"
              ? "student-dashboard"
              : "teacher-dashboard",
          );
        }
      }
    } catch (error) {
      console.error("Session check failed:", error);
      // Clear invalid token
      localStorage.removeItem("nexted_access_token");
    } finally {
      setLoading(false);
    }
  };

  const handleIntroNavigate = (
    page: "student-auth" | "teacher-auth",
  ) => {
    setCurrentPage(page);
    setUserType(
      page === "student-auth" ? "student" : "teacher",
    );
  };

  const handleLogin = (
    userType: "student" | "teacher",
    name: string,
    grade?: string,
    subject?: string,
    schoolId?: string,
  ) => {
    setUser({
      type: userType,
      name,
      grade,
      subject,
      schoolId,
    });
    setCurrentPage(
      userType === "student"
        ? "student-dashboard"
        : "teacher-dashboard",
    );
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentPage("intro");
    localStorage.removeItem("nexted_access_token");
  };

  const handleOTPReady = (
    phone: string,
    otp: string,
    isLogin: boolean,
    formData: any,
    demoMode?: boolean,
  ) => {
    setOtpData({ phone, otp, isLogin, formData, demoMode });
    setCurrentPage("otp-verification");
  };

  const handleOTPVerify = async (otp: string) => {
    if (!otpData) return;

    try {
      if (otpData.isLogin) {
        // Login flow
        const response = await verifyOTP(otpData.phone, otp);
        if (response.success && response.user) {
          handleLogin(
            response.user.userType,
            response.user.name,
            response.user.grade,
            response.user.subject,
            response.user.schoolId,
          );
        }
      } else {
        // Signup flow
        const response = await signUp({
          phone: otpData.phone,
          otp: otp,
          name: otpData.formData.name,
          userType: otpData.formData.userType || userType,
          grade: otpData.formData.grade,
          subject: otpData.formData.subject,
          schoolId: otpData.formData.schoolId,
        });

        if (response.success && response.user) {
          handleLogin(
            response.user.userType,
            response.user.name,
            response.user.grade,
            response.user.subject,
            response.user.schoolId,
          );
        }
      }
    } catch (error) {
      console.error("OTP verification failed:", error);
      throw error;
    }
  };

  const handleOTPResend = async () => {
    // Re-import sendOTP for resending
    const { sendOTP } = await import("./utils/api");
    if (!otpData) return;

    const response = await sendOTP(otpData.phone);
    if (response.success) {
      setOtpData({ ...otpData, otp: response.otp, demoMode: response.demoMode });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[#1e3a8a] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (currentPage === "intro") {
    return <IntroPage onNavigate={handleIntroNavigate} />;
  }

  if (
    currentPage === "student-auth" ||
    currentPage === "teacher-auth"
  ) {
    return (
      <AuthPage
        onLogin={handleLogin}
        initialUserType={userType}
        onBack={() => setCurrentPage("intro")}
        onOTPReady={handleOTPReady}
      />
    );
  }

  if (currentPage === "otp-verification" && otpData) {
    return (
      <OTPVerificationPage
        phoneNumber={otpData.phone}
        generatedOTP={otpData.otp}
        userType={userType}
        onVerify={handleOTPVerify}
        onBack={() =>
          setCurrentPage(
            userType === "student"
              ? "student-auth"
              : "teacher-auth",
          )
        }
        onResendOTP={handleOTPResend}
        demoMode={otpData.demoMode}
      />
    );
  }

  return (
    <>
      {user && user.type === "student" ? (
        <StudentDashboard user={user} onLogout={handleLogout} />
      ) : user && user.type === "teacher" ? (
        <TeacherDashboard user={user} onLogout={handleLogout} />
      ) : null}
    </>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
}