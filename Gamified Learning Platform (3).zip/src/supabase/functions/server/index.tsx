import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'jsr:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors());
app.use('*', logger(console.log));

// Service role client for admin operations
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Anon client for auth operations (signInWithPassword requires anon key)
const supabaseAuth = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_ANON_KEY')!,
);

// ============ AUTHENTICATION ROUTES ============

// Send OTP route
app.post('/make-server-ec14645f/auth/send-otp', async (c) => {
  try {
    const body = await c.req.json();
    const { phone } = body;

    if (!phone || phone.length !== 10) {
      return c.json({ error: 'Valid 10-digit phone number is required' }, 400);
    }

    // Generate 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    
    // Store OTP in KV with 5 minute expiry
    const otpData = {
      otp,
      phone,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 5 * 60 * 1000).toISOString() // 5 minutes
    };
    
    await kv.set(`otp:${phone}`, otpData);

    // Send SMS via Twilio
    const TWILIO_ACCOUNT_SID = Deno.env.get('TWILIO_ACCOUNT_SID');
    const TWILIO_AUTH_TOKEN = Deno.env.get('TWILIO_AUTH_TOKEN');
    const TWILIO_PHONE_NUMBER = Deno.env.get('TWILIO_PHONE_NUMBER');

    if (TWILIO_ACCOUNT_SID && TWILIO_AUTH_TOKEN && TWILIO_PHONE_NUMBER) {
      try {
        // Send real SMS via Twilio
        const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Messages.json`;
        const credentials = btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`);
        
        const formData = new URLSearchParams();
        formData.append('To', `+91${phone}`); // India country code
        formData.append('From', TWILIO_PHONE_NUMBER);
        formData.append('Body', `Your NextEd verification code is: ${otp}. Valid for 5 minutes. Do not share this code with anyone.`);

        const twilioResponse = await fetch(twilioUrl, {
          method: 'POST',
          headers: {
            'Authorization': `Basic ${credentials}`,
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: formData.toString()
        });

        if (!twilioResponse.ok) {
          const errorText = await twilioResponse.text();
          console.error('Twilio SMS error:', errorText);
          // Continue anyway - fallback to demo mode
        } else {
          console.log(`SMS sent successfully to ${phone}`);
          return c.json({ 
            success: true, 
            message: 'OTP sent to your mobile number via SMS'
          });
        }
      } catch (smsError) {
        console.error('SMS sending failed:', smsError);
        // Continue to demo mode
      }
    }

    // Fallback: Demo mode (when Twilio is not configured)
    console.log(`⚠️ DEMO MODE - OTP for ${phone}: ${otp}`);
    console.log('⚠️ Configure Twilio credentials to send real SMS');

    return c.json({ 
      success: true, 
      message: 'OTP sent successfully',
      otp, // DEMO ONLY - Remove when Twilio is configured
      demoMode: true
    });

  } catch (error) {
    console.error('Send OTP error:', error);
    return c.json({ error: 'Internal server error while sending OTP' }, 500);
  }
});

// Verify OTP and login route
app.post('/make-server-ec14645f/auth/verify-otp', async (c) => {
  try {
    const body = await c.req.json();
    const { phone, otp } = body;

    if (!phone || !otp) {
      return c.json({ error: 'Phone number and OTP are required' }, 400);
    }

    // Get stored OTP
    const otpData = await kv.get(`otp:${phone}`);

    if (!otpData) {
      return c.json({ error: 'OTP expired or not found. Please request a new OTP.' }, 400);
    }

    // Check expiry
    if (new Date() > new Date(otpData.expiresAt)) {
      await kv.del(`otp:${phone}`);
      return c.json({ error: 'OTP has expired. Please request a new one.' }, 400);
    }

    // Verify OTP
    if (otpData.otp !== otp) {
      return c.json({ error: 'Invalid OTP' }, 400);
    }

    // OTP is valid, find user by phone
    const allProfiles = await kv.getByPrefix('profile:');
    const userProfile = allProfiles.find(profile => profile.phone === phone);

    if (!userProfile) {
      return c.json({ error: 'No account found with this phone number. Please sign up first.' }, 404);
    }

    // Delete used OTP
    await kv.del(`otp:${phone}`);

    // Create a session token (using user ID as simple token)
    // In production, use proper JWT or session management
    const accessToken = userProfile.id;

    return c.json({
      success: true,
      accessToken,
      user: userProfile
    });

  } catch (error) {
    console.error('Verify OTP error:', error);
    return c.json({ error: 'Internal server error while verifying OTP' }, 500);
  }
});

// Sign up route
app.post('/make-server-ec14645f/auth/signup', async (c) => {
  try {
    const body = await c.req.json();
    const { email, password, phone, otp, name, userType, grade, subject, schoolId } = body;

    // Validation
    if (!name || !userType || !schoolId) {
      return c.json({ error: 'Missing required fields: name, userType, and schoolId are required' }, 400);
    }

    // Determine auth method
    const isEmailAuth = !!email && !!password;
    const isPhoneAuth = !!phone && !!otp;

    if (!isEmailAuth && !isPhoneAuth) {
      return c.json({ error: 'Either email/password or phone/OTP is required' }, 400);
    }

    if (isEmailAuth && password.length < 6) {
      return c.json({ error: 'Password must be at least 6 characters long' }, 400);
    }

    if (isPhoneAuth) {
      // Verify OTP for phone signup
      const otpData = await kv.get(`otp:${phone}`);
      
      if (!otpData || otpData.otp !== otp || new Date() > new Date(otpData.expiresAt)) {
        return c.json({ error: 'Invalid or expired OTP' }, 400);
      }
      
      // Delete used OTP
      await kv.del(`otp:${phone}`);
    }

    if (userType === 'student' && !grade) {
      return c.json({ error: 'Grade is required for students' }, 400);
    }

    if (userType === 'teacher' && !grade) {
      return c.json({ error: 'Grade teaching is required for teachers' }, 400);
    }

    let userId: string;

    if (isEmailAuth) {
      // Create auth user with email
      const { data: authData, error: authError } = await supabase.auth.admin.createUser({
        email,
        password,
        user_metadata: { name },
        // Automatically confirm email since email server isn't configured
        email_confirm: true
      });

      if (authError) {
        console.error('Signup auth error:', authError);
        return c.json({ error: authError.message }, 400);
      }

      userId = authData.user.id;
    } else {
      // For phone auth, generate a unique user ID
      // In production, you'd still use Supabase auth with phone
      userId = `phone_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    // Store user profile in KV store
    const profile = {
      id: userId,
      email: email || null,
      phone: phone || null,
      name,
      userType,
      grade: grade || null,
      subject: subject || null,
      schoolId,
      createdAt: new Date().toISOString()
    };

    await kv.set(`profile:${userId}`, profile);

    // If student, initialize their progress data
    if (userType === 'student') {
      const studentData = {
        userId,
        level: 1,
        points: 0,
        streak: 0,
        progress: {},
        achievements: ['first_steps']
      };
      await kv.set(`student:${userId}`, studentData);
    }

    // For phone auth signup, also return access token and user data for auto-login
    if (isPhoneAuth) {
      return c.json({ 
        success: true, 
        message: 'User created successfully',
        userId,
        accessToken: userId,
        user: profile
      });
    }

    return c.json({ 
      success: true, 
      message: 'User created successfully',
      userId 
    });

  } catch (error) {
    console.error('Signup error:', error);
    return c.json({ error: 'Internal server error during signup' }, 500);
  }
});

// Sign in route (login)
app.post('/make-server-ec14645f/auth/signin', async (c) => {
  try {
    const body = await c.req.json();
    const { email, password } = body;

    if (!email || !password) {
      return c.json({ error: 'Email and password required' }, 400);
    }

    // Use anon client for password sign in
    const { data: sessionData, error: signInError } = await supabaseAuth.auth.signInWithPassword({
      email,
      password
    });

    if (signInError) {
      console.error('Sign in error:', signInError);
      return c.json({ error: signInError.message }, 401);
    }

    const userId = sessionData.user.id;
    const accessToken = sessionData.session.access_token;

    // Get user profile
    const profile = await kv.get(`profile:${userId}`);

    if (!profile) {
      return c.json({ error: 'User profile not found' }, 404);
    }

    return c.json({
      success: true,
      accessToken,
      user: profile
    });

  } catch (error) {
    console.error('Sign in error:', error);
    return c.json({ error: 'Internal server error during sign in' }, 500);
  }
});

// Get current user profile (requires auth)
app.get('/make-server-ec14645f/auth/profile', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);

    if (error || !user) {
      console.error('Get user error:', error);
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const profile = await kv.get(`profile:${user.id}`);

    if (!profile) {
      return c.json({ error: 'Profile not found' }, 404);
    }

    return c.json({ success: true, user: profile });

  } catch (error) {
    console.error('Get profile error:', error);
    return c.json({ error: 'Internal server error while getting profile' }, 500);
  }
});

// Sign out route
app.post('/make-server-ec14645f/auth/signout', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }

    const { error } = await supabase.auth.admin.signOut(accessToken);

    if (error) {
      console.error('Sign out error:', error);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ success: true, message: 'Signed out successfully' });

  } catch (error) {
    console.error('Sign out error:', error);
    return c.json({ error: 'Internal server error during sign out' }, 500);
  }
});

// ============ TEACHER ROUTES ============

// Get students for teacher (filtered by school and grade)
app.get('/make-server-ec14645f/teacher/students', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // Get teacher profile
    const teacherProfile = await kv.get(`profile:${user.id}`);

    if (!teacherProfile || teacherProfile.userType !== 'teacher') {
      return c.json({ error: 'Not authorized as teacher' }, 403);
    }

    // Get all profiles with prefix
    const allProfiles = await kv.getByPrefix('profile:');
    
    // Filter students by school and grade
    const students = allProfiles
      .filter(profile => 
        profile.userType === 'student' &&
        profile.schoolId === teacherProfile.schoolId &&
        profile.grade === teacherProfile.grade
      )
      .map(async (profile) => {
        const studentData = await kv.get(`student:${profile.id}`);
        return {
          id: profile.id,
          name: profile.name,
          email: profile.email,
          grade: profile.grade,
          schoolId: profile.schoolId,
          progress: studentData?.progress || {},
          level: studentData?.level || 1,
          points: studentData?.points || 0,
          streak: studentData?.streak || 0
        };
      });

    const resolvedStudents = await Promise.all(students);

    return c.json({
      success: true,
      students: resolvedStudents,
      schoolId: teacherProfile.schoolId,
      grade: teacherProfile.grade
    });

  } catch (error) {
    console.error('Get students error:', error);
    return c.json({ error: 'Internal server error while fetching students' }, 500);
  }
});

// Get teacher analytics
app.get('/make-server-ec14645f/teacher/analytics', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const teacherProfile = await kv.get(`profile:${user.id}`);

    if (!teacherProfile || teacherProfile.userType !== 'teacher') {
      return c.json({ error: 'Not authorized as teacher' }, 403);
    }

    // Get all students in teacher's school and grade
    const allProfiles = await kv.getByPrefix('profile:');
    const studentProfiles = allProfiles.filter(profile => 
      profile.userType === 'student' &&
      profile.schoolId === teacherProfile.schoolId &&
      profile.grade === teacherProfile.grade
    );

    const totalStudents = studentProfiles.length;
    let totalProgress = 0;
    let activeStudents = 0;

    for (const profile of studentProfiles) {
      const studentData = await kv.get(`student:${profile.id}`);
      if (studentData) {
        const avgProgress = studentData.points / 10 || 0; // Simple calculation
        totalProgress += avgProgress;
        if (studentData.streak > 0) activeStudents++;
      }
    }

    const avgProgress = totalStudents > 0 ? Math.round(totalProgress / totalStudents) : 0;

    return c.json({
      success: true,
      analytics: {
        totalStudents,
        activeStudents,
        avgProgress,
        schoolId: teacherProfile.schoolId,
        grade: teacherProfile.grade
      }
    });

  } catch (error) {
    console.error('Get analytics error:', error);
    return c.json({ error: 'Internal server error while fetching analytics' }, 500);
  }
});

// ============ COURSE ROUTES ============

// Create a new course
app.post('/make-server-ec14645f/courses/create', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const teacherProfile = await kv.get(`profile:${user.id}`);

    if (!teacherProfile || teacherProfile.userType !== 'teacher') {
      return c.json({ error: 'Not authorized as teacher' }, 403);
    }

    const body = await c.req.json();
    const { title, description, grade, subject, lessons } = body;

    if (!title || !grade || !subject) {
      return c.json({ error: 'Title, grade, and subject are required' }, 400);
    }

    // Generate course ID
    const courseId = `course_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    const course = {
      id: courseId,
      teacherId: user.id,
      teacherName: teacherProfile.name,
      schoolId: teacherProfile.schoolId,
      title,
      description: description || '',
      grade,
      subject,
      lessons: lessons || [],
      students: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    await kv.set(`course:${courseId}`, course);

    // Add to teacher's course list
    const teacherCourses = await kv.get(`teacher_courses:${user.id}`) || [];
    teacherCourses.push(courseId);
    await kv.set(`teacher_courses:${user.id}`, teacherCourses);

    return c.json({
      success: true,
      course
    });

  } catch (error) {
    console.error('Create course error:', error);
    return c.json({ error: 'Internal server error while creating course' }, 500);
  }
});

// Get courses for a teacher
app.get('/make-server-ec14645f/courses/teacher', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const teacherProfile = await kv.get(`profile:${user.id}`);

    if (!teacherProfile || teacherProfile.userType !== 'teacher') {
      return c.json({ error: 'Not authorized as teacher' }, 403);
    }

    // Get teacher's course IDs
    const courseIds = await kv.get(`teacher_courses:${user.id}`) || [];
    
    // Fetch all courses
    const courses = await Promise.all(
      courseIds.map(async (courseId: string) => {
        const course = await kv.get(`course:${courseId}`);
        if (!course) return null;
        
        // Calculate average progress from enrolled students
        let avgProgress = 0;
        if (course.students && course.students.length > 0) {
          let totalProgress = 0;
          for (const studentId of course.students) {
            const studentData = await kv.get(`student:${studentId}`);
            if (studentData && studentData.progress && studentData.progress[courseId]) {
              totalProgress += studentData.progress[courseId];
            }
          }
          avgProgress = Math.round(totalProgress / course.students.length);
        }
        
        return {
          ...course,
          studentCount: course.students.length,
          avgProgress
        };
      })
    );

    // Filter out null courses
    const validCourses = courses.filter(c => c !== null);

    return c.json({
      success: true,
      courses: validCourses
    });

  } catch (error) {
    console.error('Get teacher courses error:', error);
    return c.json({ error: 'Internal server error while fetching courses' }, 500);
  }
});

// Get single course details
app.get('/make-server-ec14645f/courses/:courseId', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const courseId = c.req.param('courseId');
    const course = await kv.get(`course:${courseId}`);

    if (!course) {
      return c.json({ error: 'Course not found' }, 404);
    }

    // Get profile to check authorization
    const profile = await kv.get(`profile:${user.id}`);
    
    // Teachers can view their own courses, students can view enrolled courses
    if (profile.userType === 'teacher' && course.teacherId !== user.id) {
      return c.json({ error: 'Not authorized to view this course' }, 403);
    }

    if (profile.userType === 'student' && !course.students.includes(user.id)) {
      return c.json({ error: 'Not enrolled in this course' }, 403);
    }

    // Get enrolled students details for teachers
    let studentsDetails = [];
    if (profile.userType === 'teacher') {
      studentsDetails = await Promise.all(
        (course.students || []).map(async (studentId: string) => {
          const studentProfile = await kv.get(`profile:${studentId}`);
          const studentData = await kv.get(`student:${studentId}`);
          return {
            id: studentId,
            name: studentProfile?.name || 'Unknown',
            progress: studentData?.progress?.[courseId] || 0,
            level: studentData?.level || 1,
            points: studentData?.points || 0
          };
        })
      );
    }

    return c.json({
      success: true,
      course: {
        ...course,
        students: studentsDetails
      }
    });

  } catch (error) {
    console.error('Get course error:', error);
    return c.json({ error: 'Internal server error while fetching course' }, 500);
  }
});

// Update course
app.put('/make-server-ec14645f/courses/:courseId', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const courseId = c.req.param('courseId');
    const course = await kv.get(`course:${courseId}`);

    if (!course) {
      return c.json({ error: 'Course not found' }, 404);
    }

    if (course.teacherId !== user.id) {
      return c.json({ error: 'Not authorized to update this course' }, 403);
    }

    const body = await c.req.json();
    const { title, description, lessons } = body;

    const updatedCourse = {
      ...course,
      title: title || course.title,
      description: description !== undefined ? description : course.description,
      lessons: lessons || course.lessons,
      updatedAt: new Date().toISOString()
    };

    await kv.set(`course:${courseId}`, updatedCourse);

    return c.json({
      success: true,
      course: updatedCourse
    });

  } catch (error) {
    console.error('Update course error:', error);
    return c.json({ error: 'Internal server error while updating course' }, 500);
  }
});

// Delete course
app.delete('/make-server-ec14645f/courses/:courseId', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const courseId = c.req.param('courseId');
    const course = await kv.get(`course:${courseId}`);

    if (!course) {
      return c.json({ error: 'Course not found' }, 404);
    }

    if (course.teacherId !== user.id) {
      return c.json({ error: 'Not authorized to delete this course' }, 403);
    }

    // Remove from teacher's course list
    const teacherCourses = await kv.get(`teacher_courses:${user.id}`) || [];
    const updatedCourses = teacherCourses.filter((id: string) => id !== courseId);
    await kv.set(`teacher_courses:${user.id}`, updatedCourses);

    // Delete the course
    await kv.del(`course:${courseId}`);

    return c.json({
      success: true,
      message: 'Course deleted successfully'
    });

  } catch (error) {
    console.error('Delete course error:', error);
    return c.json({ error: 'Internal server error while deleting course' }, 500);
  }
});

// ============ STUDENT ROUTES ============

// Get student dashboard data
app.get('/make-server-ec14645f/student/dashboard', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const profile = await kv.get(`profile:${user.id}`);

    if (!profile || profile.userType !== 'student') {
      return c.json({ error: 'Not authorized as student' }, 403);
    }

    const studentData = await kv.get(`student:${user.id}`);

    return c.json({
      success: true,
      data: {
        profile,
        studentData: studentData || {
          level: 1,
          points: 0,
          streak: 0,
          progress: {},
          achievements: []
        }
      }
    });

  } catch (error) {
    console.error('Get student dashboard error:', error);
    return c.json({ error: 'Internal server error while fetching dashboard' }, 500);
  }
});

// Update student progress
app.post('/make-server-ec14645f/student/progress', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const body = await c.req.json();
    const { points, courseId, progressValue } = body;

    const studentData = await kv.get(`student:${user.id}`) || {
      level: 1,
      points: 0,
      streak: 0,
      progress: {},
      achievements: []
    };

    // Update points and calculate level
    studentData.points = (studentData.points || 0) + (points || 0);
    studentData.level = Math.floor(studentData.points / 100) + 1;

    // Update course progress
    if (courseId && progressValue !== undefined) {
      studentData.progress[courseId] = progressValue;
    }

    await kv.set(`student:${user.id}`, studentData);

    return c.json({
      success: true,
      data: studentData
    });

  } catch (error) {
    console.error('Update progress error:', error);
    return c.json({ error: 'Internal server error while updating progress' }, 500);
  }
});

// ============ AI TUTOR ROUTE ============

// AI Chat endpoint
app.post('/make-server-ec14645f/ai/chat', async (c) => {
  try {
    const body = await c.req.json();
    const { message, conversationHistory, language, userGrade } = body;

    if (!message || !message.trim()) {
      return c.json({ error: 'Message is required' }, 400);
    }

    const GROQ_API_KEY = Deno.env.get('GROQ_API_KEY');
    
    console.log('API Key present:', !!GROQ_API_KEY);
    console.log('API Key prefix:', GROQ_API_KEY ? GROQ_API_KEY.substring(0, 8) + '...' : 'none');
    
    if (!GROQ_API_KEY) {
      console.error('GROQ_API_KEY not configured');
      return c.json({ error: 'AI service not configured. Please add your Groq API key.' }, 500);
    }

    // Create system prompt based on language and grade
    const systemPrompts = {
      en: `You are a friendly, encouraging AI tutor for NextEd, a gamified learning platform for rural education in India. You're helping a student in grade ${userGrade || 'unknown'}.

Your role:
- Be warm, patient, and encouraging
- Explain concepts clearly at an appropriate level for the student's grade
- Use examples from daily life that rural students can relate to
- Break down complex topics into simple steps
- Encourage curiosity and learning
- Help with Math, Science, English, Social Studies, and general knowledge
- Provide step-by-step guidance for homework without just giving answers
- Be motivational and build confidence

Keep responses concise (2-4 short paragraphs max) and engaging. Use emojis sparingly to keep it friendly.`,
      hi: `आप NextEd के लिए एक दोस्ताना, उत्साहवर्धक AI शिक्षक हैं, जो भारत में ग्रामीण शिक्षा के लिए एक गेमिफाइड लर्निंग प्लेटफॉर्म है। आप कक्षा ${userGrade || 'unknown'} के छात्र की मदद कर रहे हैं।

आपकी भूमिका:
- गर्मजोशी, धैर्यवान और उत्साहवर्धक बनें
- छात्र की कक्षा के लिए उपयुक्त स्तर पर अवधारणाओं को स्पष्ट रूप से समझाएं
- दैनिक जीवन से उदाहरण का उपयोग करें जिससे ग्रामीण छात्र संबंधित हो सकें
- जटिल विषयों को सरल चरणों में विभाजित करें
- जिज्ञासा और सीखने को प्रोत्साहित करें
- गणित, विज्ञान, अंग्रेजी, सामाजिक अध्ययन और सामान्य ज्ञान में मदद करें
- सिर्फ उत्तर देने के बजाय गृहकार्य के लिए चरण-दर-चरण मार्गदर्शन प्रदान करें
- प्रेरक बनें और आत्मविश्वास बनाएं

प्रतिक्रियाओं को संक्षिप्त (अधिकतम 2-4 छोटे पैराग्राफ) और आकर्षक रखें। इसे दोस्ताना रखने के लिए कम इमोजी का उपयोग करें।

हिंदी में जवाब दें।`,
      te: `మీరు NextEd కోసం స్నేహపూర్వక, ప్రోత్సాహకారిక AI ట్యూటర్, భారతదేశంలో గ్రామీణ విద్య కోసం గేమిఫైడ్ లెర్నింగ్ ప్లాట్‌ఫారమ్. మీరు తరగతి ${userGrade || 'unknown'} విద్యార్థికి సహాయం చేస్తున్నారు।

మీ పాత్ర:
- వెచ్చగా, ఓపికగా మరియు ప్రోత్సాహకరంగా ఉండండి
- విద్యార్థి తరగతికి తగిన స్థాయిలో భావనలను స్పష్టంగా వివరించండి
- గ్రామీణ విద్యార్థులు సంబంధం కలిగి ఉండే రోజువారీ జీవితం నుండి ఉదాహరణలను ఉపయోగించండి
- సంక్లిష్ట అంశాలను సాధారణ దశలుగా విభజించండి
- ఆసక్తి మరియు నేర్చుకోవడాన్ని ప్రోత్సహించండి
- గణితం, సైన్స్, ఆంగ్లం, సామాజిక అధ్యయనాలు మరియు సాధారణ జ్ఞానంలో సహాయం చేయండి
- కేవలం సమాధానాలు ఇవ్వకుండా హోంవర్క్ కోసం దశల వారీ మార్గదర్శకత్వం అందించండి
- ప్రేరణాత్మకంగా ఉండండి మరియు ఆత్మవిశ్వాసాన్ని పెంచండి

ప్రతిస్పందనలను సంక్షిప్తంగా (గరిష్టంగా 2-4 చిన్న ప���రాగ్రాఫ్‌లు) మరియు ఆకర్షణీయంగా ఉంచండి. స్నేహపూర్వకంగా ఉంచడానికి తక్కువ ఎమోజీలను ఉపయోగించండి।

తెలుగులో సమాధానం ఇవ్వండి.`
    };

    const systemPrompt = systemPrompts[language as keyof typeof systemPrompts] || systemPrompts.en;

    // Build messages array for OpenAI
    const messages = [
      { role: 'system', content: systemPrompt },
      ...(conversationHistory || []),
      { role: 'user', content: message }
    ];

    // Call Groq API
    console.log('Calling Groq API with model: llama-3.3-70b-versatile');
    console.log('Message count:', messages.length);
    
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${GROQ_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'llama-3.3-70b-versatile', // Fast and powerful model
        messages: messages,
        temperature: 0.7,
        max_tokens: 800,
        top_p: 0.9
      })
    });

    console.log('Groq API response status:', response.status);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Groq API error status:', response.status);
      console.error('Groq API error:', errorText);
      return c.json({ 
        error: 'AI service temporarily unavailable', 
        details: errorText,
        status: response.status 
      }, 500);
    }

    const data = await response.json();
    const aiMessage = data.choices[0]?.message?.content;

    if (!aiMessage) {
      return c.json({ error: 'No response from AI' }, 500);
    }

    return c.json({ 
      success: true, 
      message: aiMessage,
      conversationId: Date.now() // Can be used for tracking
    });

  } catch (error) {
    console.error('AI chat error:', error);
    console.error('Error details:', error instanceof Error ? error.message : String(error));
    return c.json({ 
      error: 'Internal server error during AI chat',
      details: error instanceof Error ? error.message : String(error)
    }, 500);
  }
});

// Health check
app.get('/make-server-ec14645f/health', (c) => {
  return c.json({ status: 'ok', message: 'NextEd server is running' });
});

Deno.serve(app.fetch);