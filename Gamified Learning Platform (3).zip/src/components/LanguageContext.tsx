import { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'en' | 'hi' | 'te';

interface Translations {
  [key: string]: {
    en: string;
    hi: string;
    te: string;
  };
}

const translations: Translations = {
  // Branding
  appName: {
    en: 'NextEd',
    hi: 'NextEd',
    te: 'NextEd'
  },
  slogan: {
    en: 'Play, Learn, Achieve',
    hi: 'खेलें, सीखें, हासिल करें',
    te: 'ఆడండి, నేర్చుకోండి, సాధించండి'
  },
  // Auth Page
  welcome: {
    en: 'Welcome to NextEd',
    hi: 'NextEd में आपका स्वागत है',
    te: 'NextEd కి స్వాగతం'
  },
  studentLogin: {
    en: 'Student Login',
    hi: 'छात्र लॉगिन',
    te: 'విద్యార్థి లాగిన్'
  },
  teacherLogin: {
    en: 'Teacher Login',
    hi: 'शिक्षक लॉगिन',
    te: 'ఉపాధ్యాయుడు లాగిన్'
  },
  studentLoginDesc: {
    en: 'Login to access your courses',
    hi: 'अपने पाठ्यक्रमों तक पहुंचने के लिए लॉगिन करें',
    te: 'మీ కోర్సులను యాక్సెస్ చేయడానికి లాగిన్ చేయండి'
  },
  teacherLoginDesc: {
    en: 'Login to manage your students',
    hi: 'अपने छात्रों का प्रबंधन करने के लिए लॉगिन करें',
    te: 'మీ విద్యార్థులను నిర్వహించడానికి లాగిన్ చేయండి'
  },
  studentSignupDesc: {
    en: 'Create your student account',
    hi: 'अपना छात्र खाता बनाएं',
    te: 'మీ విద్యార్థి ఖాతాను సృష్టించండి'
  },
  teacherSignupDesc: {
    en: 'Create your teacher account',
    hi: 'अपना शिक्षक खाता बनाएं',
    te: 'మీ ఉపాధ్యాయ ఖాతాను సృష్టించండి'
  },
  studentSignup: {
    en: 'Student Signup',
    hi: 'छात्र साइनअप',
    te: 'విద్యార్థి సైన్అప్'
  },
  teacherSignup: {
    en: 'Teacher Signup',
    hi: 'शिक्षक साइनअप',
    te: 'ఉపాధ్యాయుడు సైన్అప్'
  },
  name: {
    en: 'Name',
    hi: 'नाम',
    te: 'పేరు'
  },
  email: {
    en: 'Email',
    hi: 'ईमेल',
    te: 'ఇమెయిల్'
  },
  password: {
    en: 'Password',
    hi: 'पासवर्ड',
    te: 'పాస్‌వర్డ్'
  },
  grade: {
    en: 'Grade',
    hi: 'कक्षा',
    te: 'తరగతి'
  },
  subject: {
    en: 'Subject',
    hi: 'विषय',
    te: 'విషయం'
  },
  schoolId: {
    en: 'School ID',
    hi: 'स्कूल आईडी',
    te: 'పాఠశాల ID'
  },
  schoolIdPlaceholder: {
    en: 'Enter your school ID (e.g., SCH001)',
    hi: 'अपना स्कूल आईडी दर्ज करें (उदा., SCH001)',
    te: 'మీ పాఠశాల IDని నమోదు చేయండి (ఉదా., SCH001)'
  },
  schoolIdHelp: {
    en: 'Your school ID ensures you connect with the right school community',
    hi: 'आपका स्कूल आईडी यह सुनिश्चित करता है कि आप सही स्कूल समुदाय से जुड़ें',
    te: 'మీ పాఠశాల ID మీరు సరైన పాఠశాల సంఘంతో కనెక్ట్ అవ్వడానికి నిర్ధారిస్తుంది'
  },
  schoolIdTeacherHelp: {
    en: 'You will only access students from your school and grade',
    hi: 'आप केवल अपने स्कूल और कक्षा के छात्रों तक पहुंच सकेंगे',
    te: 'మీరు మీ పాఠశాల మరియు తరగతి నుండి విద్యార్థులను మాత్రమే యాక్సెస్ చేయగలరు'
  },
  gradeTeaching: {
    en: 'Grade Teaching',
    hi: 'शिक्षण कक्षा',
    te: 'బోధించే తరగతి'
  },
  selectGrade: {
    en: 'Select grade',
    hi: 'कक्षा चुनें',
    te: 'తరగతిని ఎంచుకోండి'
  },
  login: {
    en: 'Login',
    hi: 'लॉगिन',
    te: 'లాగిన్'
  },
  signup: {
    en: 'Sign Up',
    hi: 'साइन अप',
    te: 'సైన్ అప్'
  },
  loggingIn: {
    en: 'Logging in...',
    hi: 'लॉगिन हो रहा है...',
    te: 'లాగిన్ అవుతోంది...'
  },
  signingUp: {
    en: 'Signing up...',
    hi: 'साइन अप हो रहा है...',
    te: 'సైన్ అప్ అవుతోంది...'
  },
  gettingStarted: {
    en: 'Getting Started',
    hi: 'शुरू करना',
    te: 'ప్రారంభించడం'
  },
  step1Signup: {
    en: 'First time? Click "Sign Up" below',
    hi: 'पहली बार? नीचे "साइन अप" पर क्लिक करें',
    te: 'మొదటి సారి? క్రింద "సైన్ అప్" క్లిక్ చేయండి'
  },
  step2Role: {
    en: 'Choose your role (Student or Teacher)',
    hi: 'अपनी भूमिका चुनें (छात्र या शिक्षक)',
    te: 'మీ పాత్రను ఎంచుకోండి (విద్యార్థి లేదా ఉపాధ్యాయుడు)'
  },
  step3School: {
    en: 'Enter your school ID (e.g., SCH001)',
    hi: 'अपनी स्कूल आईडी दर्ज करें (जैसे, SCH001)',
    te: 'మీ పాఠశాల ID ను నమోదు చేయండి (ఉదా., SCH001)'
  },
  step4Login: {
    en: 'After signup, you can login anytime',
    hi: 'साइन अप के बाद, आप कभी भी लॉगिन कर सकते हैं',
    te: 'సైన్ అప్ తర్వాత, మీరు ఎప్పుడైనా లాగిన్ చేయవచ్చు'
  },
  demoTip: {
    en: 'Tip: Use the same school ID to connect teachers and students',
    hi: 'सुझाव: शिक्षकों और छात्रों को जोड़ने के लिए समान स्कूल आईडी का उपयोग करें',
    te: 'చిట్కా: ఉపాధ్యాయులు మరియు విద్యార్థులను కనెక్ట్ చేయడానికి ఒకే పాఠశాల ID ను ఉపయోగించండి'
  },
  alreadyHaveAccount: {
    en: 'Already have an account?',
    hi: 'पहले से खाता है?',
    te: 'ఇప్పటికే ఖాతా ఉందా?'
  },
  noAccount: {
    en: "Don't have an account?",
    hi: 'खाता नहीं है?',
    te: 'ఖాతా లేదా?'
  },
  // Dashboard
  dashboard: {
    en: 'Dashboard',
    hi: 'डैशबोर्ड',
    te: 'డాష్‌బోర్డ్'
  },
  myCourses: {
    en: 'My Courses',
    hi: 'मेरे पाठ्यक्रम',
    te: 'నా కోర్సులు'
  },
  achievements: {
    en: 'Achievements',
    hi: 'उपलब्धियां',
    te: 'విజయాలు'
  },
  aiTutor: {
    en: 'AI Tutor',
    hi: 'एआई शिक्षक',
    te: 'AI ట్యూటర్'
  },
  logout: {
    en: 'Logout',
    hi: 'लॉगआउट',
    te: 'లాగౌట్'
  },
  level: {
    en: 'Level',
    hi: 'स्तर',
    te: 'స్థాయి'
  },
  points: {
    en: 'Points',
    hi: 'अंक',
    te: 'పాయింట్లు'
  },
  streak: {
    en: 'Day Streak',
    hi: 'दिन की लकीर',
    te: 'రోజుల వరుస'
  },
  progress: {
    en: 'Progress',
    hi: 'प्रगति',
    te: 'పురోగతి'
  },
  continue: {
    en: 'Continue Learning',
    hi: 'सीखना जारी रखें',
    te: 'అభ్యసించడం కొనసాగించండి'
  },
  startLearning: {
    en: 'Start Learning',
    hi: 'सीखना शुरू करें',
    te: 'అభ్యసించడం ప్రారంభించండి'
  },
  // AI Tutor
  askQuestion: {
    en: 'Ask me anything...',
    hi: 'मुझसे कुछ भी पूछें...',
    te: 'నన్ను ఏదైనా అడగండి...'
  },
  send: {
    en: 'Send',
    hi: 'भेजें',
    te: 'పంపించు'
  },
  aiTutorWelcome: {
    en: 'Hello! I am your AI tutor. How can I help you today?',
    hi: 'नमस्ते! मैं आपका एआई शिक्षक हूं। मैं आज आपकी कैसे मदद कर सकता हूं?',
    te: 'హలో! నేను మీ AI ట్యూటర్‌ని. ఈరోజు నేను మీకు ఎలా సహాయం చేయగలను?'
  },
  // Teacher Dashboard
  myStudents: {
    en: 'My Students',
    hi: 'मेरे छात्र',
    te: 'నా విద్యార్థులు'
  },
  createCourse: {
    en: 'Create Course',
    hi: 'पाठ्यक्रम बनाएं',
    te: 'కోర్సు సృష్టించండి'
  },
  analytics: {
    en: 'Analytics',
    hi: 'विश्लेषण',
    te: 'విశ్లేషణ'
  },
  totalStudents: {
    en: 'Total Students',
    hi: 'कुल छात्र',
    te: 'మొత్తం విద్యార్థులు'
  },
  activeCourses: {
    en: 'Active Courses',
    hi: 'सक्रिय पाठ्यक्रम',
    te: 'క్రియాశీల కోర్సులు'
  },
  activeStudents: {
    en: 'Active Students',
    hi: 'सक्रिय छात्र',
    te: 'క్రియాశీల విద్యార్థులు'
  },
  avgProgress: {
    en: 'Avg Progress',
    hi: 'औसत प्रगति',
    te: 'సగటు పురోగతి'
  },
  students: {
    en: 'students',
    hi: 'छात्र',
    te: 'విద్యార్థులు'
  },
  student: {
    en: 'student',
    hi: 'छात्र',
    te: 'విద్యార్థి'
  },
  teachingAt: {
    en: 'Teaching At',
    hi: 'पढ़ा रहे हैं',
    te: 'బోధిస్తున్నారు'
  },
  inYourClass: {
    en: 'in your class',
    hi: 'आपकी कक्षा में',
    te: 'మీ తరగతిలో'
  },
  filteredBy: {
    en: 'Filtered by',
    hi: 'फ़िल्टर किया गया',
    te: 'ఫిల్టర్ చేసినది'
  },
  viewDetails: {
    en: 'View Details',
    hi: 'विवरण देखें',
    te: 'వివరాలు చూడండి'
  },
  thinking: {
    en: 'Thinking...',
    hi: 'सोच रहा हूँ...',
    te: 'ఆలోచిస్తోంది...'
  },
  aiErrorMessage: {
    en: "I apologize, but I'm having trouble connecting right now. Please try again in a moment.",
    hi: 'क्षमा करें, मुझे अभी कनेक्ट करने में परेशानी हो रही है। कृपया कुछ देर में पुनः प्रयास करें।',
    te: 'క్షమించండి, నేను ప్రస్తుతం కనెక్ట్ కావడంలో సమస్య ఎదుర్కొంటున్నాను. దయచేసి కొద్ది సేపటి తర్వాత మళ్లీ ప్రయత్నించండి.'
  },
  // Intro Page
  tagline: {
    en: 'Play • Learn • Achieve',
    hi: 'खेलें • सीखें • हासिल करें',
    te: 'ఆడండి • నేర్చుకోండి • సాధించండి'
  },
  newFeatures: {
    en: 'New features coming soon!',
    hi: 'नई सुविधाएँ जल्द आ रही हैं!',
    te: 'కొత్త ఫీచర్లు త్వరలో వస్తున్నాయి!'
  },
  thanksPatience: {
    en: 'Thanks for your patience 🚀',
    hi: 'आपके धैर्य के लिए धन्यवाद 🚀',
    te: 'మీ సహనానికి ధన్యవాదాలు 🚀'
  },
  credits: {
    en: 'NextEd - Play, Learn, Achieve\n\nA gamified learning platform for rural education.\n\nBuilt with ❤️ for students and teachers.',
    hi: 'NextEd - खेलें, सीखें, हासिल करें\n\nग्रामीण शिक्षा के लिए एक गेमिफाइड लर्निंग प्लेटफॉर्म।\n\nछात्रों और शिक्षकों के लिए ❤️ से बनाया गया।',
    te: 'NextEd - ఆడండి, నేర్చుకోండి, సాధించండి\n\nగ్రామీణ విద్య కోసం గేమిఫైడ్ లెర్నింగ్ ప్లాట్‌ఫారమ్.\n\nవిద్యార్థులు మరియు ఉపాధ్యాయుల కోసం ❤️తో నిర్మించబడింది.'
  },
  quit: {
    en: 'QUIT',
    hi: 'बाहर निकलें',
    te: 'నిష్క్రమించు'
  },
  confirmQuit: {
    en: 'Are you sure you want to quit?',
    hi: 'क्या आप वाकई बाहर निकलना चाहते हैं?',
    te: 'మీరు నిజంగా నిష్క్రమించాలనుకుంటున్నారా?'
  },
  closeWindow: {
    en: 'Please close this tab to exit.',
    hi: 'बाहर निकलने के लिए कृपया यह टैब बंद करें।',
    te: 'నిష్క్రమించడానికి దయచేసి ఈ ట్యాబ్‌ను మూసివేయండి.'
  },
  settings: {
    en: 'SETTINGS',
    hi: 'सेटिंग्स',
    te: 'సెట్టింగ్‌లు'
  },
  sound: {
    en: 'Sound',
    hi: 'ध्वनि',
    te: 'ధ్వని'
  },
  brightness: {
    en: 'Brightness',
    hi: 'चमक',
    te: 'ప్రకాశం'
  },
  language: {
    en: 'Language',
    hi: 'भाषा',
    te: 'భాష'
  },
  close: {
    en: 'CLOSE',
    hi: 'बंद करें',
    te: 'మూసివేయండి'
  },
  // IntroPage specific
  gamifiedLearningPlatform: {
    en: 'Gamified Learning Platform',
    hi: 'गेमिफाइड लर्निंग प्लेटफॉर्म',
    te: 'గేమిఫైడ్ లెర్నింగ్ ప్లాట్‌ఫారమ్'
  },
  introHeading1: {
    en: 'Education that',
    hi: 'शिक्षा जो',
    te: 'విద్య ఇది'
  },
  introHeading2: {
    en: 'feels like play',
    hi: 'खेल जैसा लगता है',
    te: 'ఆట లాగా అనిపిస్తుంది'
  },
  introDescription: {
    en: 'Empowering rural students with AI-powered learning, real-time progress tracking, and achievements that matter.',
    hi: 'एआई-संचालित शिक्षा, रीयल-टाइम प्रगति ट्रैकिंग और महत्वपूर्ण उपलब्धियों के साथ ग्रामीण छात्रों को सशक्त बनाना।',
    te: 'AI-శక్తితో నడిచే అభ్యాసం, రియల్-టైమ్ పురోగతి ట్రాకింగ్ మరియు ముఖ్యమైన విజయాలతో గ్రామీణ విద్యార్థులకు శక్తినిస్తోంది.'
  },
  aiTutorLabel: {
    en: 'AI Tutor',
    hi: 'एआई शिक्षक',
    te: 'AI ట్యూటర్'
  },
  liveTracking: {
    en: 'Live Tracking',
    hi: 'लाइव ट्रैकिंग',
    te: 'లైవ్ ట్రాకింగ్'
  },
  schoolBased: {
    en: 'School Based',
    hi: 'स्कूल आधारित',
    te: 'పాఠశాల ఆధారిత'
  },
  imAStudent: {
    en: "I'm a Student",
    hi: 'मैं एक छात्र हूं',
    te: 'నేను విద్యార్థిని'
  },
  studentCardDesc: {
    en: 'Start learning with gamified courses, earn achievements, and track your progress',
    hi: 'गेमिफाइड पाठ्यक्रमों के साथ सीखना शुरू करें, उपलब्धियां अर्जित करें और अपनी प्रगति को ट्रैक करें',
    te: 'గేమిఫైడ్ కోర్సులతో అభ్యసించడం ప్రారంభించండి, విజయాలను సంపాదించండి మరియు మీ పురోగతిని ట్రాక్ చేయండి'
  },
  achievements: {
    en: 'Achievements',
    hi: 'उपलब्धियां',
    te: 'విజయాలు'
  },
  imATeacher: {
    en: "I'm a Teacher",
    hi: 'मैं एक शिक्षक हूं',
    te: 'నేను ఉపాధ్యాయుడిని'
  },
  teacherCardDesc: {
    en: 'Monitor student progress, manage courses, and access powerful analytics for your classroom',
    hi: 'छात्र प्रगति की निगरानी करें, पाठ्यक्रम प्रबंधित करें और अपनी कक्षा के लिए शक्तिशाली विश्लेषण तक पहुंचें',
    te: 'విద్యార్థుల పురోగతిని పర్యవేక్షించండి, కోర్సులను నిర్వహించండి మరియు మీ తరగతి కోసం శక్తివంతమైన విశ్లేషణలను యాక్సెస్ చేయండి'
  },
  realtime: {
    en: 'Real-time',
    hi: 'रीयल-टाइम',
    te: 'రియల్-టైమ్'
  },
  aboutNextEd: {
    en: 'About NextEd',
    hi: 'NextEd के बारे में',
    te: 'NextEd గురించి'
  },
  copyright: {
    en: '© 2025 NextEd',
    hi: '© 2025 NextEd',
    te: '© 2025 NextEd'
  },
  exit: {
    en: 'Exit',
    hi: 'बाहर निकलें',
    te: 'నిష్క్రమించు'
  },
  done: {
    en: 'Done',
    hi: 'पूर्ण',
    te: 'పూర్తి'
  }
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[key]?.[language] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within LanguageProvider');
  }
  return context;
}