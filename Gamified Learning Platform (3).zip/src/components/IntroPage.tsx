import { useState } from 'react';
import { useLanguage } from './LanguageContext';
import { SettingsModal } from './SettingsModal';
import { NextEdLogo } from './NextEdLogo';
import { motion } from 'motion/react';
import { Settings, Zap, Users, TrendingUp } from 'lucide-react';

interface IntroPageProps {
  onNavigate: (page: 'student-auth' | 'teacher-auth') => void;
}

export function IntroPage({ onNavigate }: IntroPageProps) {
  const { t } = useLanguage();
  const [showSettings, setShowSettings] = useState(false);
  const [hoveredCard, setHoveredCard] = useState<'student' | 'teacher' | null>(null);

  const handleQuit = () => {
    if (confirm(t('confirmQuit') || 'Are you sure you want to quit?')) {
      window.close();
      setTimeout(() => {
        alert(t('closeWindow') || 'Please close this tab to exit.');
      }, 100);
    }
  };

  return (
    <div className="relative min-h-screen bg-white overflow-hidden">
      {/* Background pattern - asymmetric and unique */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Large navy circle - top right - smaller on mobile */}
        <motion.div 
          className="absolute -top-20 -right-20 w-48 h-48 md:-top-32 md:-right-32 md:w-96 md:h-96 rounded-full bg-[#1e3a8a] opacity-90 md:opacity-100"
          animate={{ 
            scale: [1, 1.1, 1],
            rotate: [0, 90, 0]
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
        />
        
        {/* Medium yellow circle - bottom left - hidden on mobile */}
        <motion.div 
          className="hidden md:block absolute -bottom-24 -left-24 w-72 h-72 rounded-full bg-[#fbbf24] opacity-80"
          animate={{ 
            scale: [1, 1.2, 1],
            x: [0, 20, 0],
            y: [0, -20, 0]
          }}
          transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
        />

        {/* Small accent circles - hidden on mobile */}
        <motion.div 
          className="hidden md:block absolute top-1/3 right-1/4 w-20 h-20 rounded-full bg-[#fbbf24]"
          animate={{ y: [0, -30, 0] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div 
          className="hidden lg:block absolute bottom-1/3 left-1/3 w-16 h-16 rounded-full bg-[#1e3a8a] opacity-40"
          animate={{ x: [0, 30, 0] }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
        />

        {/* Diagonal stripe accent - hidden on mobile */}
        <div className="hidden md:block absolute top-0 right-0 w-full h-full">
          <div className="absolute top-1/4 -right-20 w-1 h-96 bg-[#fbbf24] opacity-20 rotate-45 transform origin-top" />
          <div className="absolute top-1/3 -right-32 w-1 h-80 bg-[#1e3a8a] opacity-15 rotate-45 transform origin-top" />
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Header */}
        <header className="px-6 py-6 flex items-center justify-between max-w-7xl mx-auto w-full">
          <motion.div 
            initial={{ x: -50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.6 }}
            whileHover={{ scale: 1.05 }}
            className="flex items-center gap-3 md:gap-4"
          >
            {/* Mobile logo - 80px */}
            <div className="md:hidden">
              <NextEdLogo size={80} showText={false} />
            </div>
            {/* Desktop logo - 140px */}
            <div className="hidden md:block">
              <NextEdLogo size={140} showText={false} />
            </div>
            {/* NextEd Text */}
            <div className="flex flex-col justify-center">
              <div className="text-3xl md:text-5xl tracking-tight" style={{ fontWeight: 800 }}>
                <span className="text-[#1e3a8a]">Next</span>
                <span className="text-[#fbbf24]">Ed</span>
              </div>
              <span className="text-xs md:text-sm text-gray-600 mt-0.5 tracking-wide">
                {t('slogan')}
              </span>
            </div>
          </motion.div>

          <motion.button
            onClick={() => setShowSettings(true)}
            className="p-2.5 hover:bg-gray-100 rounded-lg transition-colors"
            whileHover={{ rotate: 90 }}
            transition={{ duration: 0.3 }}
            initial={{ x: 50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
          >
            <Settings className="w-5 h-5 text-gray-700" />
          </motion.button>
        </header>

        {/* Main content */}
        <main className="flex-1 flex items-center justify-center px-6 py-8 md:py-12">
          <div className="max-w-6xl w-full">
            <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
              
              {/* Left side - Hero content */}
              <motion.div
                initial={{ x: -100, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="space-y-6 md:space-y-8 text-center lg:text-left"
              >
                <div className="space-y-4">
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="inline-block"
                  >
                    <span className="px-4 py-1.5 bg-[#fbbf24] text-[#1e3a8a] text-xs md:text-sm font-semibold rounded-full">
                      {t('gamifiedLearningPlatform')}
                    </span>
                  </motion.div>

                  <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-[#1e3a8a] leading-tight">
                    {t('introHeading1')}
                    <span className="block text-[#fbbf24]">{t('introHeading2')}</span>
                  </h2>

                  <p className="text-base md:text-xl text-gray-600 leading-relaxed max-w-xl mx-auto lg:mx-0">
                    {t('introDescription')}
                  </p>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-4 md:gap-6 max-w-md mx-auto lg:mx-0">
                  <motion.div
                    whileHover={{ y: -5 }}
                    className="space-y-1"
                  >
                    <div className="flex items-center gap-1 md:gap-2 justify-center lg:justify-start">
                      <Zap className="w-4 h-4 md:w-5 md:h-5 text-[#fbbf24]" />
                      <span className="text-xl md:text-2xl font-bold text-[#1e3a8a]">
                        {t('aiTutorLabel').split(' ')[0]}
                      </span>
                    </div>
                    <p className="text-xs md:text-sm text-gray-600">
                      {t('aiTutorLabel').split(' ')[1] || t('aiTutorLabel')}
                    </p>
                  </motion.div>

                  <motion.div
                    whileHover={{ y: -5 }}
                    className="space-y-1"
                  >
                    <div className="flex items-center gap-1 md:gap-2 justify-center lg:justify-start">
                      <TrendingUp className="w-4 h-4 md:w-5 md:h-5 text-[#fbbf24]" />
                      <span className="text-xl md:text-2xl font-bold text-[#1e3a8a]">
                        {t('liveTracking').split(' ')[0]}
                      </span>
                    </div>
                    <p className="text-xs md:text-sm text-gray-600">
                      {t('liveTracking').split(' ')[1] || t('liveTracking')}
                    </p>
                  </motion.div>

                  <motion.div
                    whileHover={{ y: -5 }}
                    className="space-y-1"
                  >
                    <div className="flex items-center gap-1 md:gap-2 justify-center lg:justify-start">
                      <Users className="w-4 h-4 md:w-5 md:h-5 text-[#fbbf24]" />
                      <span className="text-xl md:text-2xl font-bold text-[#1e3a8a]">
                        {t('schoolBased').split(' ')[0]}
                      </span>
                    </div>
                    <p className="text-xs md:text-sm text-gray-600">
                      {t('schoolBased').split(' ')[1] || t('schoolBased')}
                    </p>
                  </motion.div>
                </div>
              </motion.div>

              {/* Right side - Action cards */}
              <motion.div
                initial={{ x: 100, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                className="space-y-4 md:space-y-6"
              >
                {/* Student Card */}
                <motion.button
                  onClick={() => onNavigate('student-auth')}
                  onHoverStart={() => setHoveredCard('student')}
                  onHoverEnd={() => setHoveredCard(null)}
                  className="w-full text-left relative group"
                  whileHover={{ x: [0, 10] }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div className="relative bg-white border-2 border-[#1e3a8a] rounded-2xl p-6 md:p-8 shadow-lg hover:shadow-2xl transition-all overflow-hidden">
                    {/* Hover effect */}
                    <motion.div 
                      className="absolute inset-0 bg-[#1e3a8a]"
                      initial={{ x: '-100%' }}
                      animate={{ x: hoveredCard === 'student' ? '0%' : '-100%' }}
                      transition={{ duration: 0.3 }}
                    />
                    
                    <div className="relative z-10">
                      <div className="flex items-start justify-between mb-3 md:mb-4">
                        <div className={`w-12 h-12 md:w-14 md:h-14 rounded-xl flex items-center justify-center transition-colors ${
                          hoveredCard === 'student' ? 'bg-[#fbbf24]' : 'bg-[#1e3a8a]'
                        }`}>
                          <svg className="w-6 h-6 md:w-7 md:h-7 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                          </svg>
                        </div>
                        
                        <motion.div
                          animate={{ x: hoveredCard === 'student' ? 5 : 0 }}
                          className={`transition-colors ${hoveredCard === 'student' ? 'text-[#fbbf24]' : 'text-[#1e3a8a]'}`}
                        >
                          <svg className="w-5 h-5 md:w-6 md:h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                          </svg>
                        </motion.div>
                      </div>

                      <h3 className={`text-2xl md:text-3xl font-bold mb-2 transition-colors ${
                        hoveredCard === 'student' ? 'text-white' : 'text-[#1e3a8a]'
                      }`}>
                        {t('imAStudent')}
                      </h3>
                      
                      <p className={`text-sm md:text-base transition-colors ${
                        hoveredCard === 'student' ? 'text-gray-200' : 'text-gray-600'
                      }`}>
                        {t('studentCardDesc')}
                      </p>

                      <div className="flex flex-wrap gap-2 mt-3 md:mt-4">
                        <span className={`px-2.5 md:px-3 py-1 text-xs rounded-full transition-colors ${
                          hoveredCard === 'student' 
                            ? 'bg-white/20 text-white' 
                            : 'bg-[#fbbf24]/20 text-[#1e3a8a]'
                        }`}>
                          {t('achievements')}
                        </span>
                        <span className={`px-2.5 md:px-3 py-1 text-xs rounded-full transition-colors ${
                          hoveredCard === 'student' 
                            ? 'bg-white/20 text-white' 
                            : 'bg-[#fbbf24]/20 text-[#1e3a8a]'
                        }`}>
                          {t('aiTutorLabel')}
                        </span>
                        <span className={`px-2.5 md:px-3 py-1 text-xs rounded-full transition-colors ${
                          hoveredCard === 'student' 
                            ? 'bg-white/20 text-white' 
                            : 'bg-[#fbbf24]/20 text-[#1e3a8a]'
                        }`}>
                          {t('progress')}
                        </span>
                      </div>
                    </div>
                  </div>
                </motion.button>

                {/* Teacher Card */}
                <motion.button
                  onClick={() => onNavigate('teacher-auth')}
                  onHoverStart={() => setHoveredCard('teacher')}
                  onHoverEnd={() => setHoveredCard(null)}
                  className="w-full text-left relative group"
                  whileHover={{ x: [0, 10] }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div className="relative bg-white border-2 border-[#fbbf24] rounded-2xl p-6 md:p-8 shadow-lg hover:shadow-2xl transition-all overflow-hidden">
                    {/* Hover effect */}
                    <motion.div 
                      className="absolute inset-0 bg-[#fbbf24]"
                      initial={{ x: '-100%' }}
                      animate={{ x: hoveredCard === 'teacher' ? '0%' : '-100%' }}
                      transition={{ duration: 0.3 }}
                    />
                    
                    <div className="relative z-10">
                      <div className="flex items-start justify-between mb-3 md:mb-4">
                        <div className={`w-12 h-12 md:w-14 md:h-14 rounded-xl flex items-center justify-center transition-colors ${
                          hoveredCard === 'teacher' ? 'bg-[#1e3a8a]' : 'bg-[#fbbf24]'
                        }`}>
                          <svg className="w-6 h-6 md:w-7 md:h-7 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                          </svg>
                        </div>
                        
                        <motion.div
                          animate={{ x: hoveredCard === 'teacher' ? 5 : 0 }}
                          className={`transition-colors ${hoveredCard === 'teacher' ? 'text-[#1e3a8a]' : 'text-[#fbbf24]'}`}
                        >
                          <svg className="w-5 h-5 md:w-6 md:h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                          </svg>
                        </motion.div>
                      </div>

                      <h3 className={`text-2xl md:text-3xl font-bold mb-2 transition-colors ${
                        hoveredCard === 'teacher' ? 'text-white' : 'text-[#1e3a8a]'
                      }`}>
                        {t('imATeacher')}
                      </h3>
                      
                      <p className={`text-sm md:text-base transition-colors ${
                        hoveredCard === 'teacher' ? 'text-gray-800' : 'text-gray-600'
                      }`}>
                        {t('teacherCardDesc')}
                      </p>

                      <div className="flex flex-wrap gap-2 mt-3 md:mt-4">
                        <span className={`px-2.5 md:px-3 py-1 text-xs rounded-full transition-colors ${
                          hoveredCard === 'teacher' 
                            ? 'bg-[#1e3a8a] text-white' 
                            : 'bg-[#1e3a8a]/10 text-[#1e3a8a]'
                        }`}>
                          {t('analytics')}
                        </span>
                        <span className={`px-2.5 md:px-3 py-1 text-xs rounded-full transition-colors ${
                          hoveredCard === 'teacher' 
                            ? 'bg-[#1e3a8a] text-white' 
                            : 'bg-[#1e3a8a]/10 text-[#1e3a8a]'
                        }`}>
                          {t('schoolBased')}
                        </span>
                        <span className={`px-2.5 md:px-3 py-1 text-xs rounded-full transition-colors ${
                          hoveredCard === 'teacher' 
                            ? 'bg-[#1e3a8a] text-white' 
                            : 'bg-[#1e3a8a]/10 text-[#1e3a8a]'
                        }`}>
                          {t('realtime')}
                        </span>
                      </div>
                    </div>
                  </div>
                </motion.button>

                {/* Quick link */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.8 }}
                  className="text-center pt-4"
                >
                  <button
                    onClick={() => alert(t('credits'))}
                    className="text-sm text-gray-500 hover:text-[#1e3a8a] transition-colors underline decoration-dotted underline-offset-4"
                  >
                    {t('aboutNextEd')}
                  </button>
                </motion.div>
              </motion.div>
            </div>
          </div>
        </main>

        {/* Footer */}
        <footer className="px-6 py-6">
          <div className="max-w-7xl mx-auto flex items-center justify-between text-sm text-gray-500">
            <p>{t('copyright')}</p>
            <button
              onClick={handleQuit}
              className="hover:text-[#1e3a8a] transition-colors"
            >
              {t('exit')}
            </button>
          </div>
        </footer>
      </div>

      {/* Settings Modal */}
      {showSettings && (
        <SettingsModal onClose={() => setShowSettings(false)} />
      )}
    </div>
  );
}
