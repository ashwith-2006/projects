import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { GraduationCap, Languages, BookOpen, Loader2, AlertCircle, Eye, EyeOff, Smartphone, Mail, Clock, CheckCircle2, XCircle } from 'lucide-react';
import { useLanguage } from './LanguageContext';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { NextEdLogo } from './NextEdLogo';
import { signUp, signIn, sendOTP, verifyOTP } from '../utils/api';
import { Alert, AlertDescription } from './ui/alert';
import { InputOTP, InputOTPGroup, InputOTPSlot } from './ui/input-otp';

interface AuthPageProps {
  onLogin: (userType: 'student' | 'teacher', name: string, grade?: string, subject?: string, schoolId?: string) => void;
  initialUserType?: 'student' | 'teacher';
  onBack?: () => void;
  onOTPReady?: (phone: string, otp: string, isLogin: boolean, formData: any) => void;
}

export function AuthPage({ onLogin, initialUserType = 'student', onBack, onOTPReady }: AuthPageProps) {
  const { language, setLanguage, t } = useLanguage();
  const [isLogin, setIsLogin] = useState(true);
  const [userType, setUserType] = useState<'student' | 'teacher'>(initialUserType);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [authMethod, setAuthMethod] = useState<'email' | 'phone'>('email');
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    grade: '',
    subject: '',
    schoolId: ''
  });

  // Note: OTP is sent only when user clicks Login/Signup button, not automatically during typing



  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      if (isLogin) {
        // Login flow
        if (authMethod === 'email') {
          if (!formData.email || !formData.password) {
            setError('Email and password are required');
            setLoading(false);
            return;
          }

          const response = await signIn(formData.email, formData.password);
          if (response.success && response.user) {
            onLogin(
              response.user.userType,
              response.user.name,
              response.user.grade,
              response.user.subject,
              response.user.schoolId
            );
          }
        } else {
          // Phone OTP login - Send OTP first, then navigate to verification page
          if (!formData.phone || formData.phone.length !== 10) {
            setError('Please enter a valid 10-digit phone number');
            setLoading(false);
            return;
          }

          try {
            // Send OTP
            const otpResponse = await sendOTP(formData.phone);
            if (!otpResponse.success) {
              setError(otpResponse.error || 'Failed to send OTP');
              setLoading(false);
              return;
            }

            // Navigate to OTP verification page
            if (onOTPReady) {
              onOTPReady(formData.phone, otpResponse.otp, true, formData, otpResponse.demoMode);
            }
          } catch (err: any) {
            setError(err.message || 'Failed to send OTP');
          }
          setLoading(false);
          return;
        }
      } else {
        // Signup flow
        if (!formData.schoolId) {
          setError('School ID is required');
          setLoading(false);
          return;
        }

        if (userType === 'teacher' && !formData.grade) {
          setError('Grade teaching is required for teachers');
          setLoading(false);
          return;
        }

        if (userType === 'student' && !formData.grade) {
          setError('Grade is required for students');
          setLoading(false);
          return;
        }

        if (authMethod === 'email') {
          const response = await signUp({
            email: formData.email,
            password: formData.password,
            name: formData.name,
            userType,
            grade: formData.grade,
            subject: formData.subject,
            schoolId: formData.schoolId
          });

          if (response.success) {
            // Auto login after signup
            const loginResponse = await signIn(formData.email, formData.password);
            if (loginResponse.success && loginResponse.user) {
              onLogin(
                loginResponse.user.userType,
                loginResponse.user.name,
                loginResponse.user.grade,
                loginResponse.user.subject,
                loginResponse.user.schoolId
              );
            }
          }
        } else {
          // Phone OTP signup - Send OTP first, then navigate to verification page
          if (!formData.phone || formData.phone.length !== 10) {
            setError('Please enter a valid 10-digit phone number');
            setLoading(false);
            return;
          }

          if (!formData.name) {
            setError('Name is required');
            setLoading(false);
            return;
          }

          try {
            // Send OTP
            const otpResponse = await sendOTP(formData.phone);
            if (!otpResponse.success) {
              setError(otpResponse.error || 'Failed to send OTP');
              setLoading(false);
              return;
            }

            // Navigate to OTP verification page with form data
            if (onOTPReady) {
              onOTPReady(formData.phone, otpResponse.otp, false, {
                ...formData,
                userType
              });
            }
          } catch (err: any) {
            setError(err.message || 'Failed to send OTP');
          }
          setLoading(false);
          return;
        }
      }
    } catch (err: any) {
      console.error('Authentication error:', err);
      
      // Provide more helpful error messages
      let errorMessage = err.message || 'Authentication failed. Please try again.';
      
      if (errorMessage.includes('Invalid login credentials') || errorMessage.includes('invalid_credentials')) {
        if (isLogin) {
          errorMessage = '❌ Account not found or incorrect password. Please check your credentials or create a new account by clicking "Sign Up" below.';
        } else {
          errorMessage = 'Account creation failed. Please try again.';
        }
      } else if (errorMessage.includes('already registered') || errorMessage.includes('already exists')) {
        errorMessage = 'This email/phone is already registered. Please login instead.';
      } else if (errorMessage.includes('Email')) {
        errorMessage = 'Please enter a valid email address.';
      } else if (errorMessage.includes('Password')) {
        errorMessage = 'Password must be at least 6 characters.';
      }
      
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleLanguageChange = (value: string) => {
    setLanguage(value as 'en' | 'hi' | 'te');
  };

  const handleAuthMethodChange = (method: 'email' | 'phone') => {
    setAuthMethod(method);
    setError(null);
    setOtpSent(false);
    setGeneratedOTP('');
    setOtpExpiresAt(null);
    setTimeRemaining(0);
    setCanResend(false);
    setResendCooldown(0);
    setSendingOTP(false);
    setFormData({ ...formData, otp: '', phone: '' });
  };

  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        <div className="flex flex-col justify-center items-center gap-3 mb-10 lg:mb-12">
          <NextEdLogo className="h-24 sm:h-28 lg:h-32 w-auto max-w-full" showText={true} />
          <p className="text-[#1e3a8a] text-sm sm:text-base lg:text-lg font-medium text-center italic">{t('slogan')}</p>
        </div>
        <div className="max-w-md mx-auto">
        <div className="flex justify-between items-center mb-4">
          {onBack && (
            <Button
              variant="ghost"
              onClick={onBack}
              className="gap-2 text-[#1e3a8a]"
            >
              ← Back
            </Button>
          )}
          <div className={onBack ? '' : 'ml-auto'}>
            <Select value={language} onValueChange={handleLanguageChange}>
              <SelectTrigger className="w-32">
                <Languages className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="hi">हिंदी</SelectItem>
                <SelectItem value="te">తెలుగు</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Card className="shadow-xl">
          <CardHeader>
            <div className="flex items-center justify-center gap-2 mb-2">
              {userType === 'student' ? (
                <GraduationCap className="w-6 h-6 text-[#1e3a8a]" />
              ) : (
                <BookOpen className="w-6 h-6 text-[#1e3a8a]" />
              )}
              <CardTitle>
                {isLogin 
                  ? (userType === 'student' ? t('studentLogin') : t('teacherLogin'))
                  : (userType === 'student' ? t('studentSignup') : t('teacherSignup'))
                }
              </CardTitle>
            </div>
            <CardDescription className="text-center">
              {isLogin 
                ? (userType === 'student' ? t('studentLoginDesc') : t('teacherLoginDesc'))
                : (userType === 'student' ? t('studentSignupDesc') : t('teacherSignupDesc'))
              }
            </CardDescription>
          </CardHeader>
          <CardContent>
            {error && (
              <Alert variant="destructive" className="mb-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            {isLogin && (
              <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-sm text-blue-900">
                  <strong>ℹ️ New user?</strong> Click "Sign Up" below to create your account first.
                </p>
              </div>
            )}

            {/* Auth Method Tabs */}
            <Tabs value={authMethod} onValueChange={(val) => handleAuthMethodChange(val as 'email' | 'phone')} className="mb-4">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="email" className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  Email
                </TabsTrigger>
                <TabsTrigger value="phone" className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4" />
                  Phone
                </TabsTrigger>
              </TabsList>
            </Tabs>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              {!isLogin && (
                <div className="space-y-2">
                  <Label htmlFor="name">{t('name')}</Label>
                  <Input
                    id="name"
                    placeholder={t('name')}
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>
              )}

              {/* Email/Password Fields */}
              {authMethod === 'email' && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="email">{t('email')}</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder={t('email')}
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">{t('password')}</Label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder={t('password')}
                        value={formData.password}
                        onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                        required
                        className="pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </>
              )}

              {/* Phone/OTP Fields */}
              {authMethod === 'phone' && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <div className="relative">
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="9876543210"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value.replace(/\D/g, '') })}
                        maxLength={10}
                        required
                        className={`pr-10 transition-all ${
                          formData.phone.length === 10 
                            ? 'border-green-500' 
                            : ''
                        }`}
                      />
                      {formData.phone.length === 10 && (
                        <div className="absolute right-3 top-1/2 -translate-y-1/2">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                        </div>
                      )}
                    </div>
                    <div className="flex items-center justify-between">
                      <p className="text-xs text-muted-foreground">
                        {formData.phone.length === 10 
                          ? '✓ Valid phone number' 
                          : 'OTP will be sent when you click Login/Signup'
                        }
                      </p>
                      <span className="text-xs font-mono text-gray-500">
                        {formData.phone.length}/10
                      </span>
                    </div>
                  </div>
                </>
              )}

              {!isLogin && userType === 'student' && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="grade">{t('grade')}</Label>
                    <Select value={formData.grade} onValueChange={(val) => setFormData({ ...formData, grade: val })}>
                      <SelectTrigger>
                        <SelectValue placeholder={t('grade')} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1</SelectItem>
                        <SelectItem value="2">2</SelectItem>
                        <SelectItem value="3">3</SelectItem>
                        <SelectItem value="4">4</SelectItem>
                        <SelectItem value="5">5</SelectItem>
                        <SelectItem value="6">6</SelectItem>
                        <SelectItem value="7">7</SelectItem>
                        <SelectItem value="8">8</SelectItem>
                        <SelectItem value="9">9</SelectItem>
                        <SelectItem value="10">10</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="schoolId">{t('schoolId')}</Label>
                    <Input
                      id="schoolId"
                      placeholder={t('schoolIdPlaceholder')}
                      value={formData.schoolId}
                      onChange={(e) => setFormData({ ...formData, schoolId: e.target.value })}
                      required
                    />
                    <p className="text-xs text-muted-foreground">{t('schoolIdHelp')}</p>
                  </div>
                </>
              )}
              {!isLogin && userType === 'teacher' && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="subject">{t('subject')}</Label>
                    <Input
                      id="subject"
                      placeholder={t('subject')}
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="grade">{t('gradeTeaching')}</Label>
                    <Select value={formData.grade} onValueChange={(val) => setFormData({ ...formData, grade: val })}>
                      <SelectTrigger>
                        <SelectValue placeholder={t('selectGrade')} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">Grade 1</SelectItem>
                        <SelectItem value="2">Grade 2</SelectItem>
                        <SelectItem value="3">Grade 3</SelectItem>
                        <SelectItem value="4">Grade 4</SelectItem>
                        <SelectItem value="5">Grade 5</SelectItem>
                        <SelectItem value="6">Grade 6</SelectItem>
                        <SelectItem value="7">Grade 7</SelectItem>
                        <SelectItem value="8">Grade 8</SelectItem>
                        <SelectItem value="9">Grade 9</SelectItem>
                        <SelectItem value="10">Grade 10</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="schoolId">{t('schoolId')}</Label>
                    <Input
                      id="schoolId"
                      placeholder={t('schoolIdPlaceholder')}
                      value={formData.schoolId}
                      onChange={(e) => setFormData({ ...formData, schoolId: e.target.value })}
                      required
                    />
                    <p className="text-xs text-muted-foreground">{t('schoolIdTeacherHelp')}</p>
                  </div>
                </>
              )}
              <Button type="submit" className="w-full bg-[#1e3a8a] hover:bg-[#1e3a8a]/90 text-white" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    {isLogin ? t('loggingIn') : t('signingUp')}
                  </>
                ) : (
                  isLogin ? t('login') : t('signup')
                )}
              </Button>
            </form>
            <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-center text-sm">
                {isLogin ? (
                  <>
                    <span className="text-gray-700">{t('noAccount')} </span>
                    <button
                      type="button"
                      onClick={() => {
                        setIsLogin(false);
                        setError(null);
                      }}
                      className="text-[#1e3a8a] hover:underline font-medium"
                    >
                      {t('signup')}
                    </button>
                  </>
                ) : (
                  <>
                    <span className="text-gray-700">{t('alreadyHaveAccount')} </span>
                    <button
                      type="button"
                      onClick={() => {
                        setIsLogin(true);
                        setError(null);
                      }}
                      className="text-[#1e3a8a] hover:underline font-medium"
                    >
                      {t('login')}
                    </button>
                  </>
                )}
              </p>
            </div>
          </CardContent>
        </Card>
        </div>
      </div>
    </div>
  );
}
