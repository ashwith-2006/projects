import { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { X, Send, Bot, User, Loader2, Sparkles } from 'lucide-react';
import { useLanguage } from './LanguageContext';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface Message {
  id: number;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

interface AITutorProps {
  onClose: () => void;
  userGrade?: string;
}

export function AITutor({ onClose, userGrade }: AITutorProps) {
  const { t, language } = useLanguage();
  
  const getWelcomeMessage = () => {
    const welcomeMessages = {
      en: `Hello! I'm your AI tutor! 👋✨

I'm powered by advanced AI and I can help you with absolutely ANYTHING:

📚 **Subjects:** Math, Science, English, Social Studies, and more
✍️ **Homework:** Step-by-step guidance (not just answers!)
💡 **Concepts:** Explain anything in simple terms
🎯 **Exam Prep:** Practice questions and tips
🌟 **General Knowledge:** Curious about the world? Ask away!

I'm here 24/7 to help you learn and grow. No question is too simple or too complex!

What would you like to learn about today?`,
      hi: `नमस्ते! मैं आपका AI शिक्षक हूं! 👋✨

मैं उन्नत AI द्वारा संचालित हूं और मैं आपकी किसी भी चीज़ में मदद कर सकता हूं:

📚 **विषय:** गणित, विज्ञान, अंग्रेजी, सामाजिक अध्ययन, और अधिक
✍️ **गृहकार्य:** चरण-दर-चरण मार्गदर्शन (केवल उत्तर नहीं!)
💡 **अवधारणाएं:** सरल शब्दों में कुछ भी समझाएं
🎯 **परीक्षा तैयारी:** अभ्यास प्रश्न और सुझाव
🌟 **सामान्य ज्ञान:** दुनिया के बारे में जिज्ञासु? पूछें!

मैं आपको सीखने और बढ़ने में मदद करने के लिए 24/7 यहां हूं। कोई भी सवाल बहुत सरल या बहुत जटिल नहीं है!

आज आप किस बारे में सीखना चाहेंगे?`,
      te: `హలో! నేను మీ AI ట్యూటర్! 👋✨

నేను అధునాతన AI ద్వారా శక్తివంతం చేయబడ్డాను మరియు నేను మీకు ఏదైనా విషయంలో సహాయం చేయగలను:

📚 **విషయాలు:** గణితం, సైన్స్, ఆంగ్లం, సామాజిక అధ్యయనాలు మరియు మరిన్ని
✍️ **హోంవర్క్:** దశల వారీ మార్గదర్శకత్వం (కేవలం సమాధానాలు కాదు!)
💡 **భావనలు:** సరళమైన పదాలలో ఏదైనా వివరించండి
🎯 **పరీక్ష తయారీ:** సాధన ప్రశ్నలు మరియు చిట్కాలు
🌟 **సాధారణ జ్ఞానం:** ప్రపంచం గురించి ఆసక్తిగా ఉన్నారా? అడగండి!

మీకు నేర్చుకోవడానికి మరియు ఎదగడానికి సహాయం చేయడానికి నేను 24/7 ఇక్కడ ఉన్నాను। ఏ ప్రశ్న కూడా చాలా సరళమైనది లేదా చాలా క్లిష్టమైనది కాదు!

ఈరోజు మీరు దేని గురించి తెలుసుకోవాలనుకుంటున్నారు?`
    };
    return welcomeMessages[language as keyof typeof welcomeMessages] || welcomeMessages.en;
  };

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: getWelcomeMessage(),
      sender: 'ai',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [conversationHistory, setConversationHistory] = useState<Array<{ role: string; content: string }>>([]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now(),
      text: input,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages((prev) => [...prev, userMessage]);
    const userInput = input;
    setInput('');
    setIsLoading(true);

    try {
      // Add user message to conversation history
      const newHistory = [...conversationHistory, { role: 'user', content: userInput }];

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ec14645f/ai/chat`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: userInput,
            conversationHistory: newHistory,
            language: language,
            userGrade: userGrade || 'unknown'
          }),
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        console.error('AI API error response:', errorText);
        throw new Error(`Failed to get AI response: ${response.status} ${errorText}`);
      }

      const data = await response.json();
      
      if (data.success && data.message) {
        const aiResponse: Message = {
          id: Date.now() + 1,
          text: data.message,
          sender: 'ai',
          timestamp: new Date()
        };
        setMessages((prev) => [...prev, aiResponse]);
        
        // Update conversation history with AI response
        setConversationHistory([...newHistory, { role: 'assistant', content: data.message }]);
      } else {
        throw new Error(data.error || 'Unknown error');
      }
    } catch (error) {
      console.error('AI chat error:', error);
      
      // Extract error message if available
      const errorDetail = error instanceof Error ? error.message : String(error);
      console.error('Error detail:', errorDetail);
      
      const errorMessages = {
        en: "I apologize, but I'm having trouble connecting right now. Please try again in a moment. 🔄",
        hi: "मुझे खेद है, लेकिन मुझे अभी कनेक्ट करने में परेशानी हो रही है। कृपया एक क्षण में पुन: प्रयास करें। 🔄",
        te: "నన్ను క్షమించండి, కానీ నేను ఇప్పుడు కనెక్ట్ అవ్వడంలో ఇబ్బందులు ఎదుర్కొంటున్నాను. దయచేసి ఒక క్షణంలో మళ్లీ ప్రయత్నించండి. 🔄"
      };
      
      const errorMessage: Message = {
        id: Date.now() + 1,
        text: errorMessages[language as keyof typeof errorMessages] || errorMessages.en,
        sender: 'ai',
        timestamp: new Date()
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl h-[600px] flex flex-col shadow-2xl animate-in fade-in slide-in-from-bottom-4 duration-300">
        <CardHeader className="border-b bg-gradient-to-r from-[#1e3a8a] to-blue-700 text-white flex-shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <Bot className="w-6 h-6" />
              </div>
              <div>
                <CardTitle className="text-xl">{t('aiTutor') || 'AI Tutor'}</CardTitle>
                <p className="text-xs text-white/80 flex items-center gap-1 mt-1">
                  <Sparkles className="w-3 h-3" />
                  Powered by Advanced AI
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="text-white hover:bg-white/20"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>
        </CardHeader>

        <CardContent className="flex-1 overflow-hidden p-0 flex flex-col">
          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${
                  message.sender === 'user' ? 'flex-row-reverse' : 'flex-row'
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    message.sender === 'user'
                      ? 'bg-[#fbbf24]'
                      : 'bg-gradient-to-br from-[#1e3a8a] to-blue-600'
                  }`}
                >
                  {message.sender === 'user' ? (
                    <User className="w-4 h-4 text-white" />
                  ) : (
                    <Bot className="w-4 h-4 text-white" />
                  )}
                </div>
                <div
                  className={`flex-1 max-w-[80%] ${
                    message.sender === 'user' ? 'text-right' : 'text-left'
                  }`}
                >
                  <div
                    className={`inline-block p-3 rounded-2xl ${
                      message.sender === 'user'
                        ? 'bg-[#fbbf24] text-gray-900'
                        : 'bg-gray-100 text-gray-900'
                    }`}
                  >
                    <p className="whitespace-pre-wrap break-words">{message.text}</p>
                  </div>
                  <p className="text-xs text-gray-500 mt-1 px-1">
                    {message.timestamp.toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#1e3a8a] to-blue-600 flex items-center justify-center">
                  <Bot className="w-4 h-4 text-white" />
                </div>
                <div className="bg-gray-100 p-3 rounded-2xl">
                  <div className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin text-[#1e3a8a]" />
                    <span className="text-sm text-gray-600">
                      {language === 'hi' ? 'सोच रहा हूं...' : language === 'te' ? 'ఆలోచిస్తున్నాను...' : 'Thinking...'}
                    </span>
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="border-t p-4 bg-gray-50 flex-shrink-0">
            <div className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder={
                  language === 'hi'
                    ? 'अपना सवाल पूछें...'
                    : language === 'te'
                    ? 'మీ ప్రశ్న అడగండి...'
                    : 'Ask me anything...'
                }
                disabled={isLoading}
                className="flex-1"
              />
              <Button
                onClick={handleSend}
                disabled={isLoading || !input.trim()}
                className="bg-[#1e3a8a] hover:bg-[#1e3a8a]/90 text-white"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-xs text-center text-gray-500 mt-2">
              {language === 'hi'
                ? 'AI कभी-कभी गलतियां कर सकता है। महत्वपूर्ण जानकारी को सत्यापित करें।'
                : language === 'te'
                ? 'AI కొన్నిసార్లు తప్పులు చేయవచ్చు। ముఖ్యమైన సమాచారాన్ని ధృవీకరించండి।'
                : 'AI can make mistakes. Verify important information.'}
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
