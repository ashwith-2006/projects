import { useState, useEffect } from 'react';
import { useLanguage } from './LanguageContext';
import { Button } from './ui/button';
import { InputOTP, InputOTPGroup, InputOTPSlot } from './ui/input-otp';
import { ArrowLeft, Timer, RefreshCw, CheckCircle2, AlertCircle } from 'lucide-react';
import { NextEdLogo } from './NextEdLogo';

interface OTPVerificationPageProps {
  phoneNumber: string;
  generatedOTP?: string;
  userType: 'student' | 'teacher';
  onVerify: (otp: string) => void;
  onBack: () => void;
  onResendOTP: () => Promise<void>;
  demoMode?: boolean;
}

export function OTPVerificationPage({ 
  phoneNumber, 
  generatedOTP, 
  userType,
  onVerify, 
  onBack,
  onResendOTP,
  demoMode = false
}: OTPVerificationPageProps) {
  const { language, t } = useLanguage();
  const [otp, setOtp] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [timeRemaining, setTimeRemaining] = useState(300); // 5 minutes
  const [canResend, setCanResend] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(30);
  const [isResending, setIsResending] = useState(false);

  // Countdown timer
  useEffect(() => {
    if (timeRemaining <= 0) return;

    const interval = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          setError('OTP expired. Please request a new one.');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [timeRemaining]);

  // Resend cooldown timer
  useEffect(() => {
    if (resendCooldown <= 0) {
      setCanResend(true);
      return;
    }

    const interval = setInterval(() => {
      setResendCooldown((prev) => {
        if (prev <= 1) {
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [resendCooldown]);

  // Auto-verify when 6 digits entered
  useEffect(() => {
    if (otp.length === 6) {
      handleVerify();
    }
  }, [otp]);

  const handleVerify = async () => {
    try {
      setError(null);
      await onVerify(otp);
    } catch (error: any) {
      setError(error.message || 'Verification failed. Please try again.');
      setOtp('');
    }
  };

  const handleResend = async () => {
    if (!canResend || resendCooldown > 0) {
      setError(`Please wait ${resendCooldown} seconds before resending`);
      return;
    }

    try {
      setIsResending(true);
      setError(null);
      setOtp('');
      
      await onResendOTP();
      
      // Reset timers
      setTimeRemaining(300);
      setCanResend(false);
      setResendCooldown(30);
    } catch (err: any) {
      setError(err.message || 'Failed to resend OTP');
    } finally {
      setIsResending(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getExpirationColor = () => {
    if (timeRemaining <= 60) return 'text-red-600';
    if (timeRemaining <= 120) return 'text-orange-600';
    return 'text-green-600';
  };

  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Back Button */}
        <button
          onClick={onBack}
          className="mb-6 flex items-center gap-2 text-gray-600 hover:text-[#1e3a8a] transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>{t('back')}</span>
        </button>

        {/* Main Card */}
        <div className="bg-white rounded-2xl shadow-xl p-8 space-y-6">
          {/* Logo & Header */}
          <div className="text-center space-y-4">
            <div className="flex justify-center">
              <NextEdLogo size={60} />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                {language === 'te' && 'OTP ధృవీకరణ'}
                {language === 'hi' && 'OTP सत्यापन'}
                {language === 'en' && 'Verify OTP'}
              </h1>
              <p className="text-sm text-gray-600 mt-2">
                {language === 'te' && `మీ ఫోన్ నంబర్‌కు పంపిన 6-అంకెల కోడ్‌ను నమోదు చేయండి`}
                {language === 'hi' && `अपने फ़ोन नंबर पर भेजा गया 6-अंकीय कोड दर्ज करें`}
                {language === 'en' && 'Enter the 6-digit code sent to your phone'}
              </p>
              <p className="text-lg font-semibold text-[#1e3a8a] mt-1">
                +91 {phoneNumber}
              </p>
            </div>
          </div>

          {/* OTP Timer */}
          <div className="bg-gradient-to-r from-blue-50 to-yellow-50 rounded-lg p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Timer className={`w-5 h-5 ${getExpirationColor()}`} />
              <span className="text-sm text-gray-700">
                {language === 'te' && 'OTP గడువు ముగుస్తుంది:'}
                {language === 'hi' && 'OTP समाप्ति:'}
                {language === 'en' && 'OTP expires in:'}
              </span>
            </div>
            <span className={`font-mono font-bold ${getExpirationColor()}`}>
              {formatTime(timeRemaining)}
            </span>
          </div>

          {/* OTP Input */}
          <div className="space-y-4">
            <div className="flex justify-center">
              <InputOTP
                maxLength={6}
                value={otp}
                onChange={(value) => {
                  setOtp(value);
                  setError(null);
                }}
              >
                <InputOTPGroup>
                  <InputOTPSlot index={0} />
                  <InputOTPSlot index={1} />
                  <InputOTPSlot index={2} />
                  <InputOTPSlot index={3} />
                  <InputOTPSlot index={4} />
                  <InputOTPSlot index={5} />
                </InputOTPGroup>
              </InputOTP>
            </div>

            {/* Demo OTP Display - Only show in demo mode */}
            {demoMode && generatedOTP && (
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-center">
                <p className="text-xs text-amber-700 mb-1">
                  {language === 'te' && '⚠️ డెమో మోడ్ - మీ OTP:'}
                  {language === 'hi' && '⚠️ डेमो मोड - आपका OTP:'}
                  {language === 'en' && '⚠️ Demo Mode - Your OTP:'}
                </p>
                <p className="text-2xl font-bold text-amber-800 font-mono tracking-wider">
                  {generatedOTP}
                </p>
                <p className="text-xs text-amber-600 mt-1">
                  {language === 'en' && 'Configure Twilio for real SMS'}
                  {language === 'hi' && 'असली SMS के लिए Twilio कॉन्फ़िगर करें'}
                  {language === 'te' && 'నిజమైన SMS కోసం Twilioని కాన్ఫిగర్ చేయండి'}
                </p>
              </div>
            )}
            
            {/* Real SMS Mode Indicator */}
            {!demoMode && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-center">
                <p className="text-sm text-blue-700">
                  {language === 'te' && '📱 OTP మీ మొబైల్ నంబర్‌కు పంపబడింది'}
                  {language === 'hi' && '📱 OTP आपके मोबाइल नंबर पर भेजा गया'}
                  {language === 'en' && '📱 OTP sent to your mobile number'}
                </p>
                <p className="text-xs text-blue-600 mt-1">
                  {phoneNumber.replace(/(\d{5})(\d{5})/, '$1-$2')}
                </p>
              </div>
            )}

            {/* Error Message */}
            {error && (
              <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
                <p className="text-sm text-red-700">{error}</p>
              </div>
            )}
          </div>

          {/* Resend OTP */}
          <div className="text-center">
            <p className="text-sm text-gray-600 mb-2">
              {language === 'te' && 'OTP అందలేదా?'}
              {language === 'hi' && 'OTP नहीं मिला?'}
              {language === 'en' && "Didn't receive OTP?"}
            </p>
            <Button
              type="button"
              variant="ghost"
              onClick={handleResend}
              disabled={!canResend || resendCooldown > 0 || isResending}
              className="text-[#1e3a8a] hover:text-[#1e3a8a]/80 font-semibold"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isResending ? 'animate-spin' : ''}`} />
              {canResend && resendCooldown === 0 ? (
                <>
                  {language === 'te' && 'మళ్లీ పంపండి'}
                  {language === 'hi' && 'फिर से भेजें'}
                  {language === 'en' && 'Resend OTP'}
                </>
              ) : (
                <>
                  {language === 'te' && `మళ్లీ పంపండి (${resendCooldown}సె)`}
                  {language === 'hi' && `फिर से भेजें (${resendCooldown}s)`}
                  {language === 'en' && `Resend OTP (${resendCooldown}s)`}
                </>
              )}
            </Button>
          </div>

          {/* Help Text */}
          <div className="text-center pt-4 border-t border-gray-200">
            <p className="text-xs text-gray-500">
              {language === 'te' && '💡 OTP స్వయంచాలకంగా ధృవీకరించబడుతుంది'}
              {language === 'hi' && '💡 OTP स्वचालित रूप से सत्यापित हो जाएगा'}
              {language === 'en' && '💡 OTP will be verified automatically'}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-6">
          <p className="text-sm text-gray-600">
            {language === 'te' && '🛡️ మీ డేటా సురక్షితం మరియు గోప్యంగా ఉంచబడుతుంది'}
            {language === 'hi' && '🛡️ आपका डेटा सुरक्षित और निजी रखा गया है'}
            {language === 'en' && '🛡️ Your data is kept secure and private'}
          </p>
        </div>
      </div>
    </div>
  );
}
