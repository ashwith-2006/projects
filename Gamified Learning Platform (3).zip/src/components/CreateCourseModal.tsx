import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Loader2, Plus, X } from 'lucide-react';
import { createCourse } from '../utils/api';
import { useLanguage } from './LanguageContext';
import { Alert, AlertDescription } from './ui/alert';

interface CreateCourseModalProps {
  open: boolean;
  onClose: () => void;
  onCourseCreated?: () => void;
  defaultGrade?: string;
  defaultSubject?: string;
}

export function CreateCourseModal({ 
  open, 
  onClose, 
  onCourseCreated,
  defaultGrade,
  defaultSubject 
}: CreateCourseModalProps) {
  const { t } = useLanguage();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    grade: defaultGrade || '',
    subject: defaultSubject || '',
  });
  const [lessons, setLessons] = useState<Array<{ title: string; description: string }>>([]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formData.title.trim()) {
      setError('Course title is required');
      return;
    }

    if (!formData.grade) {
      setError('Grade is required');
      return;
    }

    if (!formData.subject.trim()) {
      setError('Subject is required');
      return;
    }

    try {
      setLoading(true);
      const response = await createCourse({
        title: formData.title,
        description: formData.description,
        grade: formData.grade,
        subject: formData.subject,
        lessons: lessons.filter(l => l.title.trim() !== '')
      });

      if (response.success) {
        onCourseCreated?.();
        handleClose();
      } else {
        setError('Failed to create course');
      }
    } catch (err: any) {
      console.error('Failed to create course:', err);
      setError(err.message || 'Failed to create course');
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setFormData({
      title: '',
      description: '',
      grade: defaultGrade || '',
      subject: defaultSubject || '',
    });
    setLessons([]);
    setError(null);
    onClose();
  };

  const addLesson = () => {
    setLessons([...lessons, { title: '', description: '' }]);
  };

  const removeLesson = (index: number) => {
    setLessons(lessons.filter((_, i) => i !== index));
  };

  const updateLesson = (index: number, field: 'title' | 'description', value: string) => {
    const updated = [...lessons];
    updated[index][field] = value;
    setLessons(updated);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{t('createCourse')}</DialogTitle>
          <DialogDescription>
            Create a new course for your students to enroll in
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Basic Information */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Course Title *</Label>
              <Input
                id="title"
                placeholder="e.g., Mathematics - Algebra Basics"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Describe what students will learn in this course..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="grade">Grade *</Label>
                <Select 
                  value={formData.grade} 
                  onValueChange={(val) => setFormData({ ...formData, grade: val })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select grade" />
                  </SelectTrigger>
                  <SelectContent>
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((grade) => (
                      <SelectItem key={grade} value={grade.toString()}>
                        Grade {grade}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="subject">Subject *</Label>
                <Input
                  id="subject"
                  placeholder="e.g., Mathematics"
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  required
                />
              </div>
            </div>
          </div>

          {/* Lessons Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label>Lessons (Optional)</Label>
                <p className="text-sm text-muted-foreground">Add lessons to your course structure</p>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addLesson}
                className="gap-2"
              >
                <Plus className="w-4 h-4" />
                Add Lesson
              </Button>
            </div>

            {lessons.length > 0 && (
              <div className="space-y-3">
                {lessons.map((lesson, index) => (
                  <div key={index} className="border rounded-lg p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm font-medium">Lesson {index + 1}</Label>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removeLesson(index)}
                        className="h-6 w-6 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                    <Input
                      placeholder="Lesson title"
                      value={lesson.title}
                      onChange={(e) => updateLesson(index, 'title', e.target.value)}
                    />
                    <Textarea
                      placeholder="Lesson description (optional)"
                      value={lesson.description}
                      onChange={(e) => updateLesson(index, 'description', e.target.value)}
                      rows={2}
                    />
                  </div>
                ))}
              </div>
            )}

            {lessons.length === 0 && (
              <div className="text-center py-8 border-2 border-dashed rounded-lg">
                <p className="text-sm text-muted-foreground">
                  No lessons added yet. Click "Add Lesson" to get started.
                </p>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={handleClose} disabled={loading}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-[#1e3a8a] hover:bg-[#1e3a8a]/90" 
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Creating...
                </>
              ) : (
                'Create Course'
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}