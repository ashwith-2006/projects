import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { 
  Trophy, 
  Flame, 
  Star, 
  Target,
  LogOut,
  Languages,
  MessageCircle,
  TrendingUp,
  BookOpen,
  ChevronRight,
  Lock,
  CheckCircle2,
  Play
} from 'lucide-react';
import { useLanguage } from './LanguageContext';
import { AITutor } from './AITutor';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { NextEdLogo } from './NextEdLogo';
import { motion } from 'motion/react';

interface StudentDashboardProps {
  user: { 
    name: string;
    grade?: string;
    schoolId?: string;
  };
  onLogout: () => void;
}

const courses = [
  { 
    id: 1, 
    title: { en: 'Mathematics', hi: 'गणित', te: 'గణితం' },
    progress: 65, 
    level: 8,
    totalLessons: 24,
    completedLessons: 16,
    color: '#3b82f6',
    icon: '📐',
    nextLesson: { en: 'Algebra Basics', hi: 'बीजगणित मूल बातें', te: 'బీజగణిత ప్రాథమికాలు' }
  },
  { 
    id: 2, 
    title: { en: 'Science', hi: 'विज्ञान', te: 'విజ్ఞాన శాస్త్రం' },
    progress: 45, 
    level: 5,
    totalLessons: 20,
    completedLessons: 9,
    color: '#10b981',
    icon: '🔬',
    nextLesson: { en: 'Photosynthesis', hi: 'प्रकाश संश्लेषण', te: 'కిరణజన్య సంయోగక్రియ' }
  },
  { 
    id: 3, 
    title: { en: 'English', hi: 'अंग्रेज़ी', te: 'ఆంగ్లం' },
    progress: 80, 
    level: 12,
    totalLessons: 18,
    completedLessons: 14,
    color: '#8b5cf6',
    icon: '📚',
    nextLesson: { en: 'Grammar Pro', hi: 'व्याकरण प्रो', te: 'వ్యాకరణ ప్రో' }
  },
  { 
    id: 4, 
    title: { en: 'Social Studies', hi: 'सामाजिक अध्ययन', te: 'సామాజిక శాస్త్రం' },
    progress: 30, 
    level: 3,
    totalLessons: 22,
    completedLessons: 7,
    color: '#f59e0b',
    icon: '🌍',
    nextLesson: { en: 'World History', hi: 'विश्व इतिहास', te: 'ప్రపంచ చరిత్ర' }
  }
];

const achievements = [
  { id: 1, title: { en: 'First Steps', hi: 'पहला कदम', te: 'మొదటి అడుగులు' }, description: { en: 'Complete first lesson', hi: 'पहला पाठ पूरा करें', te: 'మొదటి పాఠం పూర్తి చేయండి' }, icon: '🎯', unlocked: true },
  { id: 2, title: { en: 'Week Warrior', hi: 'सप्ताह योद्धा', te: 'వారం యోధుడు' }, description: { en: '7 day streak', hi: '7 दिन की लकीर', te: '7 రోజుల స్ట్రీక్' }, icon: '⚔️', unlocked: true },
  { id: 3, title: { en: 'Quiz Master', hi: 'क्विज़ मास्टर', te: 'క్విజ్ మాస్టర్' }, description: { en: 'Ace 10 quizzes', hi: '10 क्विज़ में सफलता', te: '10 క్విజ్‌లు పూర్తి చేయండి' }, icon: '🏆', unlocked: true },
  { id: 4, title: { en: 'Perfect Score', hi: 'पूर्ण स्कोर', te: 'పరిపూర్ణ స్కోరు' }, description: { en: 'Score 100% on test', hi: 'परीक्षा में 100%', te: 'పరీక్షలో 100%' }, icon: '💯', unlocked: false },
  { id: 5, title: { en: 'Speed Learner', hi: 'तेज़ सीखने वाला', te: 'వేగవంతమైన అభ్యాసి' }, description: { en: 'Finish 5 lessons in a day', hi: 'एक दिन में 5 पाठ', te: 'ఒక రోజులో 5 పాఠాలు' }, icon: '⚡', unlocked: false },
  { id: 6, title: { en: 'Helping Hand', hi: 'मददगार हाथ', te: 'సహాయపు చేయి' }, description: { en: 'Help a classmate', hi: 'एक सहपाठी की मदद करें', te: 'సహవిద్యార్థికి సహాయం చేయండి' }, icon: '🤝', unlocked: true }
];

export function StudentDashboard({ user, onLogout }: StudentDashboardProps) {
  const { language, setLanguage, t } = useLanguage();
  const [showAITutor, setShowAITutor] = useState(false);
  const [activeTab, setActiveTab] = useState<'courses' | 'achievements'>('courses');

  const handleLanguageChange = (value: string) => {
    setLanguage(value as 'en' | 'hi' | 'te');
  };

  const currentLevel = 28;
  const currentXP = 1420;
  const xpToNextLevel = 2000;
  const streakDays = 7;

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Left - Logo & User */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <NextEdLogo size={40} showText={false} />
                <div className="text-2xl tracking-tight" style={{ fontWeight: 800 }}>
                  <span className="text-[#1e3a8a]">Next</span>
                  <span className="text-[#fbbf24]">Ed</span>
                </div>
              </div>
              <div className="hidden md:flex items-center gap-3">
                <div className="w-px h-8 bg-gray-300"></div>
                <div>
                  <div className="text-sm text-gray-900" style={{ fontWeight: 600 }}>{user.name}</div>
                  <div className="text-xs text-gray-500">
                    {user.grade && user.schoolId ? `${user.schoolId} • Grade ${user.grade}` : 'Student'}
                  </div>
                </div>
              </div>
            </div>

            {/* Right - Actions */}
            <div className="flex items-center gap-2">
              <Select value={language} onValueChange={handleLanguageChange}>
                <SelectTrigger className="w-32 h-9 text-sm">
                  <Languages className="w-4 h-4 mr-1" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="hi">हिंदी</SelectItem>
                  <SelectItem value="te">తెలుగు</SelectItem>
                </SelectContent>
              </Select>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowAITutor(!showAITutor)}
                className="gap-1.5 h-9"
              >
                <MessageCircle className="w-4 h-4" />
                <span className="hidden sm:inline">AI Tutor</span>
              </Button>
              
              <Button 
                variant="ghost" 
                size="sm"
                onClick={onLogout}
                className="gap-1.5 h-9"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Logout</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          {/* Level Card */}
          <Card className="border-0 shadow-sm bg-white">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="text-sm text-gray-600">Current Level</div>
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#1e3a8a] to-blue-600 flex items-center justify-center">
                  <Target className="w-5 h-5 text-white" />
                </div>
              </div>
              <div className="text-3xl text-gray-900 mb-1" style={{ fontWeight: 700 }}>{currentLevel}</div>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-[#1e3a8a] to-blue-600 rounded-full transition-all duration-500"
                    style={{ width: `${(currentXP / xpToNextLevel) * 100}%` }}
                  ></div>
                </div>
                <div className="text-xs text-gray-500 whitespace-nowrap">{currentXP}/{xpToNextLevel} XP</div>
              </div>
            </CardContent>
          </Card>

          {/* Points Card */}
          <Card className="border-0 shadow-sm bg-gradient-to-br from-[#fbbf24] to-yellow-500">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="text-sm text-yellow-900/70">Total Points</div>
                <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                  <Star className="w-5 h-5 text-white" />
                </div>
              </div>
              <div className="text-3xl text-white mb-1" style={{ fontWeight: 700 }}>{currentXP.toLocaleString()}</div>
              <div className="flex items-center gap-1 text-xs text-yellow-900/70">
                <TrendingUp className="w-3 h-3" />
                <span>+150 this week</span>
              </div>
            </CardContent>
          </Card>

          {/* Streak Card */}
          <Card className="border-0 shadow-sm bg-gradient-to-br from-orange-500 to-red-500">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="text-sm text-orange-100">Day Streak</div>
                <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                  <Flame className="w-5 h-5 text-white" />
                </div>
              </div>
              <div className="text-3xl text-white mb-1" style={{ fontWeight: 700 }}>{streakDays} days</div>
              <div className="text-xs text-orange-100">Keep it up! 🔥</div>
            </CardContent>
          </Card>

          {/* Achievements Card */}
          <Card className="border-0 shadow-sm bg-white">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="text-sm text-gray-600">Achievements</div>
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                  <Trophy className="w-5 h-5 text-white" />
                </div>
              </div>
              <div className="text-3xl text-gray-900 mb-1" style={{ fontWeight: 700 }}>
                {achievements.filter(a => a.unlocked).length}/{achievements.length}
              </div>
              <div className="text-xs text-gray-500">Unlocked</div>
            </CardContent>
          </Card>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 mb-6 border-b border-gray-200">
          <button
            onClick={() => setActiveTab('courses')}
            className={`px-4 py-3 text-sm transition-colors relative ${
              activeTab === 'courses'
                ? 'text-[#1e3a8a]'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            style={{ fontWeight: 600 }}
          >
            <BookOpen className="w-4 h-4 inline mr-2" />
            My Courses
            {activeTab === 'courses' && (
              <motion.div
                layoutId="activeTab"
                className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#1e3a8a]"
              />
            )}
          </button>
          <button
            onClick={() => setActiveTab('achievements')}
            className={`px-4 py-3 text-sm transition-colors relative ${
              activeTab === 'achievements'
                ? 'text-[#1e3a8a]'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            style={{ fontWeight: 600 }}
          >
            <Trophy className="w-4 h-4 inline mr-2" />
            Achievements
            {activeTab === 'achievements' && (
              <motion.div
                layoutId="activeTab"
                className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#1e3a8a]"
              />
            )}
          </button>
        </div>

        {/* Courses Tab */}
        {activeTab === 'courses' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {courses.map((course, index) => (
              <motion.div
                key={course.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Card className="border-0 shadow-sm hover:shadow-md transition-shadow bg-white overflow-hidden group">
                  <CardContent className="p-0">
                    {/* Header with color accent */}
                    <div 
                      className="h-2"
                      style={{ backgroundColor: course.color }}
                    ></div>
                    
                    <div className="p-6">
                      {/* Course Info */}
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-start gap-3">
                          <div 
                            className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl"
                            style={{ backgroundColor: `${course.color}15` }}
                          >
                            {course.icon}
                          </div>
                          <div>
                            <h3 className="text-lg text-gray-900 mb-0.5" style={{ fontWeight: 600 }}>
                              {course.title[language]}
                            </h3>
                            <div className="flex items-center gap-2">
                              <Badge 
                                variant="secondary" 
                                className="text-xs px-2 py-0.5"
                                style={{ 
                                  backgroundColor: `${course.color}15`,
                                  color: course.color,
                                  border: 'none'
                                }}
                              >
                                Level {course.level}
                              </Badge>
                              <span className="text-xs text-gray-500">
                                {course.completedLessons}/{course.totalLessons} lessons
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl text-gray-900" style={{ fontWeight: 700 }}>{course.progress}%</div>
                        </div>
                      </div>

                      {/* Progress Bar */}
                      <div className="mb-4">
                        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                          <motion.div
                            className="h-full rounded-full"
                            style={{ backgroundColor: course.color }}
                            initial={{ width: 0 }}
                            animate={{ width: `${course.progress}%` }}
                            transition={{ duration: 1, delay: 0.2 + index * 0.1 }}
                          />
                        </div>
                      </div>

                      {/* Next Lesson */}
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="text-xs text-gray-500 mb-1">Next Lesson</div>
                          <div className="text-sm text-gray-700" style={{ fontWeight: 500 }}>
                            {course.nextLesson[language]}
                          </div>
                        </div>
                        <Button 
                          size="sm"
                          className="gap-1.5 shadow-sm"
                          style={{ 
                            backgroundColor: course.color,
                            color: 'white'
                          }}
                        >
                          <Play className="w-4 h-4" />
                          Continue
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}

        {/* Achievements Tab */}
        {activeTab === 'achievements' && (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {achievements.map((achievement, index) => (
              <motion.div
                key={achievement.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Card className={`border-0 shadow-sm hover:shadow-md transition-all ${
                  achievement.unlocked 
                    ? 'bg-white cursor-pointer' 
                    : 'bg-gray-50 opacity-60'
                }`}>
                  <CardContent className="p-6 text-center relative">
                    {/* Lock icon for locked achievements */}
                    {!achievement.unlocked && (
                      <div className="absolute top-3 right-3">
                        <Lock className="w-4 h-4 text-gray-400" />
                      </div>
                    )}
                    
                    {/* Check icon for unlocked achievements */}
                    {achievement.unlocked && (
                      <div className="absolute top-3 right-3">
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                      </div>
                    )}

                    {/* Icon */}
                    <div className="text-5xl mb-3">{achievement.icon}</div>
                    
                    {/* Title */}
                    <div className={`text-sm mb-1 ${achievement.unlocked ? 'text-gray-900' : 'text-gray-500'}`} style={{ fontWeight: 600 }}>
                      {achievement.title[language]}
                    </div>
                    
                    {/* Description */}
                    <div className="text-xs text-gray-500">
                      {achievement.description[language]}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </main>

      {showAITutor && (
        <AITutor onClose={() => setShowAITutor(false)} userGrade={user.grade} />
      )}
    </div>
  );
}
