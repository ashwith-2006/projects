import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { 
  Users, 
  BookOpen, 
  TrendingUp, 
  Loader2,
  Calendar,
  Award,
  Edit,
  Trash2
} from 'lucide-react';
import { getCourseDetails, deleteCourse } from '../utils/api';
import { useLanguage } from './LanguageContext';
import { Alert, AlertDescription } from './ui/alert';

interface CourseDetailsModalProps {
  courseId: string;
  open: boolean;
  onClose: () => void;
  onCourseDeleted?: () => void;
}

export function CourseDetailsModal({ courseId, open, onClose, onCourseDeleted }: CourseDetailsModalProps) {
  const { t } = useLanguage();
  const [course, setCourse] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open && courseId) {
      loadCourseDetails();
    }
  }, [open, courseId]);

  const loadCourseDetails = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await getCourseDetails(courseId);
      if (response.success) {
        setCourse(response.course);
      } else {
        setError('Failed to load course details');
      }
    } catch (err: any) {
      console.error('Failed to load course:', err);
      setError(err.message || 'Failed to load course details');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this course? This action cannot be undone.')) {
      return;
    }

    try {
      setDeleting(true);
      const response = await deleteCourse(courseId);
      if (response.success) {
        onCourseDeleted?.();
        onClose();
      } else {
        setError('Failed to delete course');
      }
    } catch (err: any) {
      console.error('Failed to delete course:', err);
      setError(err.message || 'Failed to delete course');
    } finally {
      setDeleting(false);
    }
  };

  const getAverageProgress = () => {
    if (!course?.students || course.students.length === 0) return 0;
    const total = course.students.reduce((sum: number, student: any) => sum + (student.progress || 0), 0);
    return Math.round(total / course.students.length);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-2xl">
            <BookOpen className="w-6 h-6 text-[#1e3a8a]" />
            {course?.title || 'Course Details'}
          </DialogTitle>
          {course && (
            <DialogDescription>
              {course.grade && <Badge variant="secondary" className="mr-2">Grade {course.grade}</Badge>}
              {course.subject && <Badge variant="secondary">{course.subject}</Badge>}
            </DialogDescription>
          )}
        </DialogHeader>

        {loading ? (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-[#1e3a8a]" />
          </div>
        ) : error ? (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        ) : course ? (
          <div className="space-y-6">
            {/* Course Overview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">{t('students')}</p>
                      <p className="text-2xl font-bold text-[#1e3a8a]">{course.students?.length || 0}</p>
                    </div>
                    <Users className="w-8 h-8 text-[#1e3a8a] opacity-50" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Avg Progress</p>
                      <p className="text-2xl font-bold text-[#fbbf24]">{getAverageProgress()}%</p>
                    </div>
                    <TrendingUp className="w-8 h-8 text-[#fbbf24] opacity-50" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Lessons</p>
                      <p className="text-2xl font-bold text-green-600">{course.lessons?.length || 0}</p>
                    </div>
                    <Award className="w-8 h-8 text-green-600 opacity-50" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Description */}
            {course.description && (
              <div>
                <h3 className="font-semibold mb-2">Description</h3>
                <p className="text-muted-foreground">{course.description}</p>
              </div>
            )}

            {/* Course Info */}
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                Created: {new Date(course.createdAt).toLocaleDateString()}
              </div>
              {course.updatedAt !== course.createdAt && (
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  Updated: {new Date(course.updatedAt).toLocaleDateString()}
                </div>
              )}
            </div>

            {/* Tabs for Lessons and Students */}
            <Tabs defaultValue="students" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="students">
                  <Users className="w-4 h-4 mr-2" />
                  Students ({course.students?.length || 0})
                </TabsTrigger>
                <TabsTrigger value="lessons">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Lessons ({course.lessons?.length || 0})
                </TabsTrigger>
              </TabsList>

              <TabsContent value="students" className="space-y-3 mt-4">
                {course.students && course.students.length > 0 ? (
                  course.students.map((student: any) => (
                    <Card key={student.id}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-[#1e3a8a] rounded-full flex items-center justify-center text-white font-semibold">
                              {student.name.charAt(0)}
                            </div>
                            <div>
                              <h4 className="font-semibold">{student.name}</h4>
                              <p className="text-sm text-muted-foreground">
                                Level {student.level} • {student.points} points
                              </p>
                            </div>
                          </div>
                          <Badge 
                            variant="secondary"
                            className={
                              student.progress >= 80 
                                ? 'bg-green-100 text-green-700'
                                : student.progress >= 50
                                ? 'bg-blue-100 text-blue-700'
                                : 'bg-orange-100 text-orange-700'
                            }
                          >
                            {student.progress}% Complete
                          </Badge>
                        </div>
                        <Progress value={student.progress || 0} className="h-2" />
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <Users className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>No students enrolled yet</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="lessons" className="space-y-3 mt-4">
                {course.lessons && course.lessons.length > 0 ? (
                  course.lessons.map((lesson: any, index: number) => (
                    <Card key={index}>
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div className="w-8 h-8 bg-[#1e3a8a] rounded-full flex items-center justify-center text-white text-sm font-semibold flex-shrink-0">
                            {index + 1}
                          </div>
                          <div className="flex-1">
                            <h4 className="font-semibold mb-1">{lesson.title || `Lesson ${index + 1}`}</h4>
                            {lesson.description && (
                              <p className="text-sm text-muted-foreground">{lesson.description}</p>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <BookOpen className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>No lessons added yet</p>
                    <p className="text-sm mt-1">Edit the course to add lessons</p>
                  </div>
                )}
              </TabsContent>
            </Tabs>

            {/* Action Buttons */}
            <div className="flex justify-between pt-4 border-t">
              <Button
                variant="destructive"
                onClick={handleDelete}
                disabled={deleting}
                className="gap-2"
              >
                {deleting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Deleting...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    Delete Course
                  </>
                )}
              </Button>
              <div className="flex gap-2">
                <Button variant="outline" onClick={onClose}>
                  Close
                </Button>
                <Button className="bg-[#1e3a8a] hover:bg-[#1e3a8a]/90 gap-2">
                  <Edit className="w-4 h-4" />
                  Edit Course
                </Button>
              </div>
            </div>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}