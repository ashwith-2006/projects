import { useState, useEffect } from 'react';
import { useLanguage } from './LanguageContext';
import { X, Volume2, VolumeX, Sun, Moon, Languages, Globe } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface SettingsModalProps {
  onClose: () => void;
}

export function SettingsModal({ onClose }: SettingsModalProps) {
  const { language, setLanguage, t } = useLanguage();
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [brightness, setBrightness] = useState(100);

  useEffect(() => {
    // Load saved settings
    const savedSound = localStorage.getItem('nexted_sound_enabled');
    const savedBrightness = localStorage.getItem('nexted_brightness');
    
    if (savedSound !== null) {
      setSoundEnabled(savedSound === 'true');
    }
    if (savedBrightness !== null) {
      setBrightness(Number(savedBrightness));
      applyBrightness(Number(savedBrightness));
    }
  }, []);

  const handleSoundToggle = () => {
    const newValue = !soundEnabled;
    setSoundEnabled(newValue);
    localStorage.setItem('nexted_sound_enabled', String(newValue));
    
    // You can add sound feedback here if needed
    if (newValue) {
      // Play a test sound
    }
  };

  const applyBrightness = (value: number) => {
    document.documentElement.style.filter = `brightness(${value}%)`;
  };

  const handleBrightnessChange = (value: number) => {
    setBrightness(value);
    localStorage.setItem('nexted_brightness', String(value));
    applyBrightness(value);
  };

  const handleLanguageChange = (lang: 'en' | 'hi' | 'te') => {
    setLanguage(lang);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
        {/* Backdrop */}
        <motion.div 
          className="absolute inset-0 bg-black/60 backdrop-blur-md"
          onClick={onClose}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        />
        
        {/* Modal */}
        <motion.div 
          className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden"
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          transition={{ type: "spring", duration: 0.5 }}
        >
          {/* Header with gradient */}
          <div className="relative bg-gradient-to-r from-[#1e3a8a] to-[#1e40af] px-6 py-8 overflow-hidden">
            {/* Decorative circles */}
            <motion.div 
              className="absolute -top-10 -right-10 w-32 h-32 rounded-full bg-[#fbbf24] opacity-20"
              animate={{ 
                scale: [1, 1.2, 1],
                rotate: [0, 180, 0]
              }}
              transition={{ duration: 10, repeat: Infinity }}
            />
            <motion.div 
              className="absolute -bottom-10 -left-10 w-40 h-40 rounded-full bg-[#fbbf24] opacity-10"
              animate={{ 
                scale: [1, 1.3, 1],
                rotate: [0, -180, 0]
              }}
              transition={{ duration: 12, repeat: Infinity }}
            />
            
            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors backdrop-blur-sm z-10"
            >
              <X className="w-5 h-5 text-white" />
            </button>

            {/* Title */}
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-2">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  className="p-2 bg-white/10 rounded-xl backdrop-blur-sm"
                >
                  <Globe className="w-6 h-6 text-[#fbbf24]" />
                </motion.div>
                <h2 className="text-3xl font-bold text-white">
                  {t('settings')}
                </h2>
              </div>
              <p className="text-blue-100 text-sm ml-14">
                {language === 'hi' ? 'अपने अनुभव को अनुकूलित करें' : language === 'te' ? 'మీ అనుభవాన్ని అనుకూలీకరించండి' : 'Customize your experience'}
              </p>
            </div>
          </div>

          <div className="p-6 space-y-4">
            
            {/* Language Settings - Featured */}
            <motion.div 
              className="bg-gradient-to-br from-[#fbbf24]/10 to-[#fbbf24]/5 rounded-2xl p-5 border-2 border-[#fbbf24]/20"
              whileHover={{ scale: 1.02 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-[#fbbf24] rounded-lg">
                  <Languages className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-[#1e3a8a]">
                    {t('language')} / भाषा / భాష
                  </h3>
                  <p className="text-xs text-gray-600">
                    {language === 'hi' ? 'अपनी पसंदीदा भाषा चुनें' : language === 'te' ? 'మీ ఇష్టమైన భాషను ఎంచుకోండి' : 'Choose your preferred language'}
                  </p>
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-2">
                <motion.button
                  onClick={() => handleLanguageChange('en')}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`py-3 px-2 rounded-xl font-medium transition-all ${
                    language === 'en'
                      ? 'bg-[#1e3a8a] text-white shadow-lg'
                      : 'bg-white border-2 border-gray-200 text-gray-700 hover:border-[#fbbf24]'
                  }`}
                >
                  English
                </motion.button>
                <motion.button
                  onClick={() => handleLanguageChange('hi')}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`py-3 px-2 rounded-xl font-medium transition-all ${
                    language === 'hi'
                      ? 'bg-[#1e3a8a] text-white shadow-lg'
                      : 'bg-white border-2 border-gray-200 text-gray-700 hover:border-[#fbbf24]'
                  }`}
                >
                  हिंदी
                </motion.button>
                <motion.button
                  onClick={() => handleLanguageChange('te')}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`py-3 px-2 rounded-xl font-medium transition-all ${
                    language === 'te'
                      ? 'bg-[#1e3a8a] text-white shadow-lg'
                      : 'bg-white border-2 border-gray-200 text-gray-700 hover:border-[#fbbf24]'
                  }`}
                >
                  తెలుగు
                </motion.button>
              </div>
            </motion.div>

            {/* Sound Settings */}
            <motion.div 
              className="bg-gray-50 rounded-2xl p-5 border border-gray-200"
              whileHover={{ scale: 1.02 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${soundEnabled ? 'bg-[#1e3a8a]' : 'bg-gray-300'}`}>
                    {soundEnabled ? (
                      <Volume2 className="w-5 h-5 text-white" />
                    ) : (
                      <VolumeX className="w-5 h-5 text-gray-600" />
                    )}
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">
                      {t('sound')}
                    </h3>
                    <p className="text-xs text-gray-600">
                      {soundEnabled 
                        ? (language === 'hi' ? 'सक्षम' : language === 'te' ? 'ప్రారంభించబడింది' : 'Enabled')
                        : (language === 'hi' ? 'अक्षम' : language === 'te' ? 'నిలిపివేయబడింది' : 'Disabled')
                      }
                    </p>
                  </div>
                </div>
                <button
                  onClick={handleSoundToggle}
                  className={`relative w-14 h-8 rounded-full transition-all ${
                    soundEnabled ? 'bg-[#1e3a8a]' : 'bg-gray-300'
                  }`}
                >
                  <motion.div
                    className="absolute top-1 left-1 w-6 h-6 bg-white rounded-full shadow-md"
                    animate={{
                      x: soundEnabled ? 24 : 0
                    }}
                    transition={{ type: "spring", stiffness: 500, damping: 30 }}
                  />
                </button>
              </div>
            </motion.div>

            {/* Brightness Settings */}
            <motion.div 
              className="bg-gray-50 rounded-2xl p-5 border border-gray-200"
              whileHover={{ scale: 1.02 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${brightness > 100 ? 'bg-[#fbbf24]' : 'bg-[#1e3a8a]'}`}>
                      {brightness > 100 ? (
                        <Sun className="w-5 h-5 text-white" />
                      ) : (
                        <Moon className="w-5 h-5 text-white" />
                      )}
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">
                        {t('brightness')}
                      </h3>
                      <p className="text-xs text-gray-600">
                        {language === 'hi' ? 'स्क्रीन की चमक समायोजित करें' : language === 'te' ? 'స్క్రీన్ ప్రకాశాన్ని సర్దుబాటు చేయండి' : 'Adjust screen brightness'}
                      </p>
                    </div>
                  </div>
                  <div className="text-lg font-bold text-[#1e3a8a]">
                    {brightness}%
                  </div>
                </div>
                
                {/* Custom Slider */}
                <div className="relative">
                  <input
                    type="range"
                    min="50"
                    max="150"
                    value={brightness}
                    onChange={(e) => handleBrightnessChange(Number(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                  />
                  <div 
                    className="absolute top-0 left-0 h-2 bg-gradient-to-r from-[#1e3a8a] to-[#fbbf24] rounded-lg pointer-events-none"
                    style={{ width: `${((brightness - 50) / 100) * 100}%` }}
                  />
                </div>
              </div>
            </motion.div>
          </div>

          {/* Footer */}
          <div className="px-6 pb-6">
            <motion.button
              onClick={onClose}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full bg-gradient-to-r from-[#1e3a8a] to-[#1e40af] text-white py-4 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all text-center"
            >
              {t('done')}
            </motion.button>
          </div>
        </motion.div>

        <style>{`
          .slider::-webkit-slider-thumb {
            appearance: none;
            width: 24px;
            height: 24px;
            background: white;
            border: 3px solid #1e3a8a;
            border-radius: 50%;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
            position: relative;
            z-index: 10;
          }

          .slider::-moz-range-thumb {
            width: 24px;
            height: 24px;
            background: white;
            border: 3px solid #1e3a8a;
            border-radius: 50%;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
            position: relative;
            z-index: 10;
          }

          .slider::-webkit-slider-thumb:hover {
            border-color: #fbbf24;
            transform: scale(1.1);
          }

          .slider::-moz-range-thumb:hover {
            border-color: #fbbf24;
            transform: scale(1.1);
          }
        `}</style>
      </div>
    </AnimatePresence>
  );
}
