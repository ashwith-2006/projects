import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  Users, 
  BarChart3,
  LogOut,
  Languages,
  Plus,
  TrendingUp,
  BookOpen,
  Loader2
} from 'lucide-react';
import { useLanguage } from './LanguageContext';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { NextEdLogo } from './NextEdLogo';
import { getTeacherStudents, getTeacherAnalytics, getTeacherCourses, signOut } from '../utils/api';
import { CreateCourseModal } from './CreateCourseModal';
import { CourseDetailsModal } from './CourseDetailsModal';

interface TeacherDashboardProps {
  user: { 
    name: string;
    grade?: string;
    subject?: string;
    schoolId?: string;
  };
  onLogout: () => void;
}

const courseColors = [
  'from-blue-500 to-cyan-500',
  'from-green-500 to-emerald-500',
  'from-purple-500 to-pink-500',
  'from-orange-500 to-red-500',
  'from-indigo-500 to-purple-500',
  'from-yellow-500 to-orange-500'
];

export function TeacherDashboard({ user, onLogout }: TeacherDashboardProps) {
  const { language, setLanguage, t } = useLanguage();
  const [students, setStudents] = useState<any[]>([]);
  const [analytics, setAnalytics] = useState<any>(null);
  const [courses, setCourses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateCourse, setShowCreateCourse] = useState(false);
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);

  const handleLanguageChange = (value: string) => {
    setLanguage(value as 'en' | 'hi' | 'te');
  };

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      
      // Load students
      const studentsResponse = await getTeacherStudents();
      if (studentsResponse.success) {
        setStudents(studentsResponse.students || []);
      }

      // Load analytics
      const analyticsResponse = await getTeacherAnalytics();
      if (analyticsResponse.success) {
        setAnalytics(analyticsResponse.analytics);
      }

      // Load courses
      const coursesResponse = await getTeacherCourses();
      if (coursesResponse.success) {
        setCourses(coursesResponse.courses || []);
      }
    } catch (error) {
      console.error('Failed to load teacher dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut();
      onLogout();
    } catch (error) {
      console.error('Logout error:', error);
      onLogout(); // Logout anyway
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 sm:py-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 sm:gap-4">
            <NextEdLogo className="h-10 sm:h-12 w-auto max-w-[180px] sm:max-w-[220px]" showText={true} />
            <div className="h-8 w-px bg-gray-300 hidden md:block"></div>
            <div className="hidden md:block">
              <h4 className="text-gray-900">{user.name}</h4>
              <p className="text-gray-500 text-sm">{t('dashboard')}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            <Select value={language} onValueChange={handleLanguageChange}>
              <SelectTrigger className="w-28 sm:w-32">
                <Languages className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="hi">हिंदी</SelectItem>
                <SelectItem value="te">తెలుగు</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={handleLogout} className="gap-2">
              <LogOut className="w-4 h-4" />
              {t('logout')}
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {loading ? (
          <div className="flex justify-center items-center min-h-[400px]">
            <Loader2 className="w-8 h-8 animate-spin text-[#1e3a8a]" />
          </div>
        ) : (
          <>
        {/* School and Grade Info Banner */}
        {(user.schoolId || user.grade) && (
          <div className="bg-gradient-to-r from-[#1e3a8a] to-[#1e40af] text-white rounded-lg p-4 mb-6 shadow-lg">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-4 flex-wrap">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
                    <BookOpen className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs opacity-90">{t('teachingAt')}</p>
                    <p className="font-semibold">
                      {user.schoolId || 'N/A'} {user.grade && `• ${t('grade')} ${user.grade}`}
                    </p>
                  </div>
                </div>
                {user.subject && (
                  <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                    {user.subject}
                  </Badge>
                )}
              </div>
              <div className="text-sm opacity-90">
                <Users className="w-4 h-4 inline mr-1" />
                {students.length} {students.length === 1 ? t('student') : t('students')} {t('inYourClass')}
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-[#1e3a8a] text-white">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="opacity-90">{t('totalStudents')}</p>
                  <h2 className="text-white">{analytics?.totalStudents || students.length}</h2>
                </div>
                <Users className="w-12 h-12 opacity-80" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-[#fbbf24] text-white">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="opacity-90">{t('activeStudents')}</p>
                  <h2 className="text-white">{analytics?.activeStudents || 0}</h2>
                </div>
                <BookOpen className="w-12 h-12 opacity-80" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-600 to-emerald-600 text-white">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="opacity-90">{t('avgProgress')}</p>
                  <h2 className="text-white">{analytics?.avgProgress || 0}%</h2>
                </div>
                <TrendingUp className="w-12 h-12 opacity-80" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>{t('myCourses')}</CardTitle>
                  <CardDescription>
                    {courses.length} {t('activeCourses').toLowerCase()}
                  </CardDescription>
                </div>
                <Button 
                  className="bg-[#1e3a8a] hover:bg-[#1e3a8a]/90 text-white gap-2"
                  onClick={() => setShowCreateCourse(true)}
                >
                  <Plus className="w-4 h-4" />
                  {t('createCourse')}
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {courses.length > 0 ? (
                courses.map((course, index) => (
                  <div
                    key={course.id}
                    className="p-4 rounded-lg border bg-gradient-to-r from-gray-50 to-white hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h3 className="text-gray-900">{course.title}</h3>
                        <p className="text-muted-foreground">
                          {course.studentCount || 0} {t('students')}
                        </p>
                      </div>
                      <Badge className={`bg-gradient-to-r ${courseColors[index % courseColors.length]} text-white`}>
                        {course.avgProgress || 0}%
                      </Badge>
                    </div>
                    <Progress value={course.avgProgress || 0} className="mb-3" />
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full"
                      onClick={() => setSelectedCourseId(course.id)}
                    >
                      {t('viewDetails')}
                    </Button>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <BookOpen className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>No courses created yet</p>
                  <p className="text-sm mt-1">Click "Create Course" to get started</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{t('myStudents')}</CardTitle>
              <CardDescription>
                {students.length} {t('students').toLowerCase()}
                {user.schoolId && user.grade && (
                  <span className="text-xs block mt-1 text-muted-foreground">
                    📌 {t('filteredBy')} {user.schoolId} • {t('grade')} {user.grade}
                  </span>
                )}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {students.map((student) => (
                  <div
                    key={student.id}
                    className="flex items-center justify-between p-3 rounded-lg border bg-white hover:shadow-sm transition-shadow"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-[#1e3a8a] rounded-full flex items-center justify-center text-white">
                        {student.name.charAt(0)}
                      </div>
                      <div>
                        <h4 className="text-gray-900">{student.name}</h4>
                        <p className="text-muted-foreground">
                          {t('grade')} {student.grade} • {t('level')} {student.level || 1}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      {student.streak > 0 && (
                        <Badge variant="secondary" className="bg-[#fbbf24]/20 text-[#fbbf24]">
                          🔥 {student.streak}
                        </Badge>
                      )}
                      <div className="text-right">
                        <p className="text-muted-foreground">{student.points || 0} {t('points')}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              {t('analytics')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-4 rounded-lg bg-gradient-to-br from-blue-50 to-cyan-50 border border-blue-200">
                <p className="text-muted-foreground mb-1">Active Today</p>
                <h3 className="text-blue-600">67</h3>
              </div>
              <div className="p-4 rounded-lg bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200">
                <p className="text-muted-foreground mb-1">Completed Lessons</p>
                <h3 className="text-green-600">142</h3>
              </div>
              <div className="p-4 rounded-lg bg-gradient-to-br from-purple-50 to-pink-50 border border-purple-200">
                <p className="text-muted-foreground mb-1">Avg Quiz Score</p>
                <h3 className="text-purple-600">78%</h3>
              </div>
              <div className="p-4 rounded-lg bg-gradient-to-br from-orange-50 to-red-50 border border-orange-200">
                <p className="text-muted-foreground mb-1">Questions Asked</p>
                <h3 className="text-orange-600">256</h3>
              </div>
            </div>
          </CardContent>
        </Card>
        </>
        )}
      </main>

      {/* Modals */}
      <CreateCourseModal
        open={showCreateCourse}
        onClose={() => setShowCreateCourse(false)}
        onCourseCreated={() => {
          loadDashboardData();
          setShowCreateCourse(false);
        }}
        defaultGrade={user.grade}
        defaultSubject={user.subject}
      />

      {selectedCourseId && (
        <CourseDetailsModal
          courseId={selectedCourseId}
          open={!!selectedCourseId}
          onClose={() => setSelectedCourseId(null)}
          onCourseDeleted={() => {
            loadDashboardData();
            setSelectedCourseId(null);
          }}
        />
      )}
    </div>
  );
}