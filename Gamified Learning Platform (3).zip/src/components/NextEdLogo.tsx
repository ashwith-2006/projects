import logoImage from 'figma:asset/49e4d3ba1a9a603e3b1b95a8d497687dbeb2a237.png';
import shieldOnlyImage from 'figma:asset/b88409077224e9825485d7716f90343d0d67cfde.png';

interface NextEdLogoProps {
  className?: string;
  showText?: boolean;
  size?: number;
}

export function NextEdLogo({ className, showText = true, size }: NextEdLogoProps) {
  // If size is provided, use it; otherwise use className or default
  const logoClassName = size ? '' : (className || "h-12");
  const logoStyle = size ? { width: `${size}px`, height: `${size}px`, objectFit: 'contain' as const } : { objectFit: 'contain' as const };
  
  return (
    <img 
      src={showText ? logoImage : shieldOnlyImage}
      alt="NextEd Logo" 
      className={logoClassName}
      style={logoStyle}
    />
  );
}