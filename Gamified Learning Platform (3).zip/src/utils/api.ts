import { projectId, publicAnonKey } from './supabase/info';

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-ec14645f`;

// Store access token in memory (in production, use secure storage)
let accessToken: string | null = null;

export function setAccessToken(token: string | null) {
  accessToken = token;
  if (token) {
    localStorage.setItem('nexted_access_token', token);
  } else {
    localStorage.removeItem('nexted_access_token');
  }
}

export function getAccessToken(): string | null {
  if (!accessToken) {
    accessToken = localStorage.getItem('nexted_access_token');
  }
  return accessToken;
}

async function apiCall(endpoint: string, options: RequestInit = {}) {
  const token = getAccessToken();
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token || publicAnonKey}`,
    ...options.headers,
  };

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers,
    });

    const data = await response.json();

    if (!response.ok) {
      console.error(`API Error [${endpoint}]:`, data);
      throw new Error(data.error || 'API request failed');
    }

    return data;
  } catch (error) {
    console.error(`API Call Error [${endpoint}]:`, error);
    throw error;
  }
}

// ============ AUTH API ============

export async function signUp(userData: {
  email?: string;
  password?: string;
  phone?: string;
  otp?: string;
  name: string;
  userType: 'student' | 'teacher';
  grade?: string;
  subject?: string;
  schoolId: string;
}) {
  const data = await apiCall('/auth/signup', {
    method: 'POST',
    body: JSON.stringify(userData),
  });
  return data;
}

export async function signIn(email: string, password: string) {
  const data = await apiCall('/auth/signin', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });
  
  if (data.success && data.accessToken) {
    setAccessToken(data.accessToken);
  }
  
  return data;
}

export async function getProfile() {
  const data = await apiCall('/auth/profile', {
    method: 'GET',
  });
  return data;
}

export async function signOut() {
  try {
    await apiCall('/auth/signout', {
      method: 'POST',
    });
  } finally {
    setAccessToken(null);
  }
}

export async function sendOTP(phone: string) {
  const data = await apiCall('/auth/send-otp', {
    method: 'POST',
    body: JSON.stringify({ phone }),
  });
  return data;
}

export async function verifyOTP(phone: string, otp: string) {
  const data = await apiCall('/auth/verify-otp', {
    method: 'POST',
    body: JSON.stringify({ phone, otp }),
  });
  
  if (data.success && data.accessToken) {
    setAccessToken(data.accessToken);
  }
  
  return data;
}

// ============ TEACHER API ============

export async function getTeacherStudents() {
  const data = await apiCall('/teacher/students', {
    method: 'GET',
  });
  return data;
}

export async function getTeacherAnalytics() {
  const data = await apiCall('/teacher/analytics', {
    method: 'GET',
  });
  return data;
}

// ============ STUDENT API ============

export async function getStudentDashboard() {
  const data = await apiCall('/student/dashboard', {
    method: 'GET',
  });
  return data;
}

export async function updateStudentProgress(progressData: {
  points?: number;
  courseId?: string;
  progressValue?: number;
}) {
  const data = await apiCall('/student/progress', {
    method: 'POST',
    body: JSON.stringify(progressData),
  });
  return data;
}

// ============ COURSE API ============

export async function createCourse(courseData: {
  title: string;
  description?: string;
  grade: string;
  subject: string;
  lessons?: any[];
}) {
  const data = await apiCall('/courses/create', {
    method: 'POST',
    body: JSON.stringify(courseData),
  });
  return data;
}

export async function getTeacherCourses() {
  const data = await apiCall('/courses/teacher', {
    method: 'GET',
  });
  return data;
}

export async function getCourseDetails(courseId: string) {
  const data = await apiCall(`/courses/${courseId}`, {
    method: 'GET',
  });
  return data;
}

export async function updateCourse(courseId: string, updates: {
  title?: string;
  description?: string;
  lessons?: any[];
}) {
  const data = await apiCall(`/courses/${courseId}`, {
    method: 'PUT',
    body: JSON.stringify(updates),
  });
  return data;
}

export async function deleteCourse(courseId: string) {
  const data = await apiCall(`/courses/${courseId}`, {
    method: 'DELETE',
  });
  return data;
}

// ============ HEALTH CHECK ============

export async function healthCheck() {
  const data = await apiCall('/health', {
    method: 'GET',
  });
  return data;
}